﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_dept_Upt : System.Web.UI.Page
{
    SqlConnection cnn;
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        string ID;
        if (!IsPostBack)
        {
            ID = Request.QueryString["staID"];
            bindMyListBoxData();
            ListBox1.SelectedValue = ID;
            DisPlayDept(ID);
        }

    }
    protected void DisPlayDept(string ID)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "tbDept";
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.Parameters.AddWithValue("@code", ID);
            cmd.CommandText = "SELECT * FROM " + tbName + " ";
            cmd.CommandText += "WHERE dept_ID = @code";
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();

            while (myDR.Read())
            {
                txtName.Text = myDR["dept_Name"].ToString();
                txtNotes.Text = myDR["dept_Notes"].ToString();
            }

            cnn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void bindMyListBoxData()
    {
        string ds = myConnectString;
        SqlConnection conn = new SqlConnection(ds);
        SqlDataReader dr = null;
        string dc = "select dept_ID from tbDept ";
        SqlCommand cmd = new SqlCommand(dc, conn);
        conn.Open();
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            ListBox1.Items.Add(new ListItem(dr["dept_ID"].ToString()));
        }
        cmd.Cancel();
        dr.Close();
        conn.Close();
        conn.Dispose();
    }

    protected void btnUptPhoto_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "tbDept";
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.Parameters.AddWithValue("code", ListBox1.SelectedValue);
            cmd.Parameters.AddWithValue("Name", txtName.Text);
            cmd.Parameters.AddWithValue("Notes", txtNotes.Text);
            cmd.CommandText = "UPDATE " + tbName + " SET ";
            cmd.CommandText += "dep_Notes = @Notes";
            cmd.CommandText += ", dept_Name = @Name";
            cmd.CommandText += " WHERE dept_ID  = @code ";

            cmd.ExecuteNonQuery();

            cnn.Close();
            Response.Write("<p>更新成功!</p>");
            // 顯示更新結果
            DisPlayDept(ListBox1.SelectedValue);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }

    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DisPlayDept(ListBox1.SelectedValue);
    }
}