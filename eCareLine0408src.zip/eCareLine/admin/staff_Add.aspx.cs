﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.IO;
public partial class admin_staff_add : System.Web.UI.Page
{
    cfg cfg = new cfg();
    LoginUsr LoginUsr;
    protected void Page_Load(object sender, EventArgs e)
    {
        //第一次執行時, 綁定DropDownList, 在後端直接用ADO.NET處理
        if (!IsPostBack)
        {             // 
            txtstaff_ID.Text = cfg.getcde("STF");
            DLfrom();
        }

    }

    string photoFileName;
    SqlConnection cnn;
    // string myConnectString = @"Server='localhost\SQLEXPRESS'; database='MyDB1';Integrated Security=True;";
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    //綁定DropDownList在後端直接用ADO.NET處理(方式1)(迴圈去read)。
    protected void DLfrom()
    {
        string ds = myConnectString;
        SqlConnection conn = new SqlConnection(ds);
        SqlDataReader dr = null;
        string dc = "select dept_ID from tbDept ";
        SqlCommand cmd = new SqlCommand(dc, conn);
        conn.Open();
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            lstdept_ID.Items.Add(new ListItem(dr["dept_ID"].ToString()));
        }
        cmd.Cancel();
        dr.Close();
        conn.Close();
        conn.Dispose();
        //http://msdn.microsoft.com/zh-tw/library/cc464128(v=vs.71).aspx
    }
    protected void myUploadFile()
    {
        try
        {
            string folderPath = Server.MapPath("Uploads/");
            //Check whether Directory (Folder) exists.
            if (!Directory.Exists(folderPath))
            {
                //If Directory (Folder) does not exists Create it.
                Directory.CreateDirectory(folderPath);
            }
            // 判斷 Server 上檔案名稱是否有重覆情況，有的話必須進行更名
            string filename = FU1.FileName;
            string extension = Path.GetExtension(filename).ToLowerInvariant();
            // 絶對路徑+檔名
            string serverFilePath = Path.Combine(folderPath, filename);
            string fileNameOnly = Path.GetFileNameWithoutExtension(filename);
            int fileCount = 1;
            while (File.Exists(serverFilePath))
            {
                // 重覆檔案的命名規則為 檔名_1、檔名_2 以此類推
                filename = string.Concat(fileNameOnly, "_", fileCount, extension);
                serverFilePath = Path.Combine(folderPath, filename);
                fileCount++;
            }
            FU1.SaveAs(serverFilePath);
            photoFileName = "Uploads/" + filename;
            //Display the Picture in Image control.
            imgPhoto.ImageUrl = photoFileName;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            // MessageBox.Show(this, ex.Message);
        }

    }
    protected void btnStaffAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();

            myUploadFile();  // 要先執行此自訂方法, 檔案名稱才會正確. 

            string commString = "INSERT INTO tbStaff (staff_ID, dept_ID, staff_Name, staff_PhotoFileName, staff_Bdate, staff_Phone, staff_Salary, Staff_Remark) ";
            commString += " VALUES (@staID, @depID, @staName, @staFileName, @staBdate, @staPhone, @staSalary, @staRemark)";
            SqlCommand myComm = new SqlCommand(commString, cnn);
            //myComm.Parameters.Add("@staID", SqlDbType.NVarChar);
            //myComm.Parameters.Add("@depID", SqlDbType.NVarChar);
            //myComm.Parameters.Add("@staName", SqlDbType.NVarChar);
            //myComm.Parameters.Add("@staPhone", SqlDbType.NVarChar);

            myComm.Parameters.AddWithValue("@staID", txtstaff_ID.Text);
            // myComm.Parameters.AddWithValue("@depID", txtdept_ID.Text);
            myComm.Parameters.AddWithValue("@depID", lstdept_ID.SelectedValue);
            myComm.Parameters.AddWithValue("@staName", txtName.Text);
            // myComm.Parameters.AddWithValue("@staBdate", txtBdate.Text);
            myComm.Parameters.Add("@staBdate", SqlDbType.Date);
            myComm.Parameters["@staBdate"].Value = txtBdate.Text;
            myComm.Parameters.AddWithValue("@staFileName", photoFileName);
            myComm.Parameters.AddWithValue("@staPhone", txtPhone.Text);

            myComm.Parameters.AddWithValue("@staSalary", txtSalary.Text);
            // myComm.Parameters.Add("@staSalary", SqlDbType.Int);
            // myComm.Parameters["@staSalary"].Value = int.Parse(txtSalary.Text);

            myComm.Parameters.AddWithValue("@staRemark", txtRemark.Text);
            // 
            // Response.Write("<p>存檔前程式</p>");
            myComm.ExecuteNonQuery();
            // 
            Response.Write("<p>存檔程式成功</p>");

            // MessageBox.Show(this, "新增成功!");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            // MessageBox.Show(this, ex.Message);
        }

    }

    protected void lstdept_ID_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.CommandText = "SELECT * FROM tbDept ";
            cmd.CommandText += " WHERE dept_ID = @code";
            cmd.Parameters.AddWithValue("@code", lstdept_ID.SelectedValue);
            // Response.Write("<p>" + cmd.CommandText + " : " + lstdept_ID.SelectedValue + "</p>");
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();
            if (myDR.Read())
            {
                lblDeptName.Text = myDR["dept_Name"].ToString();
            }
            cnn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
}