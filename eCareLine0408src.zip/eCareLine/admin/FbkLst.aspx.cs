﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_FbkLst : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            txtSdt.Text = "2019/01/01";
            txtSdt.Attributes.Add("type", "date");
            //txtSdt.Attributes["onclick"] = "showCalendar(this, this, 'yyyy/mm/dd','tw',1)";

            txtEdt.Text = DateTime.Now.AddDays(1).ToString("yyyy/MM/dd");
            txtEdt.Attributes.Add("type", "date");
            //txtEdt.Attributes["onclick"] = "showCalendar(this, this, 'yyyy/mm/dd','tw',1)";

            System.Data.DataTable tbFTP = cfg.getTypLst("FTP");
            String[] FTPtxt = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypSub", true);
            FTPtxt[0] = "全部狀態";
            String[] FTPval = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypTid", true);
            WebFormBase.GenDropDownListItem(selTyp, FTPtxt, FTPval, "");
            tbFTP.Dispose();



            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbFbkCde from tbFbk where 1=1 ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        if (SelItem.SelectedValue == "ALL") {
                            SqlStr += " and (tbFbkNme like @tbFbkNmeA or tbFbkSex like @tbFbkSexA or tbFbkCty like @tbFbkCtyA or tbFbkCom like @tbFbkComA or tbFbkTel like @tbFbkTelA or tbFbkEml like @tbFbkEmlA or tbFbkCon like @tbFbkConA or tbFbkStu like @tbFbkStuA or tbFbkRon like @tbFbkRonA or tbFbkCde like @tbFbkCdeA)";
                            IzDataSource.ParametersAdd("tbFbkNmeA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkSexA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkCtyA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkComA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkTelA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkEmlA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkConA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkStuA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkRonA", "%" + txtWhat.Text + "%");
                            IzDataSource.ParametersAdd("tbFbkCdeA", "%" + txtWhat.Text + "%");
                        }
                        else
                        {
                            SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                            IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                        }
                    }

                    if (txtSdt.Text != "")
                    {
                        SqlStr += " and tbFbkCdt >= @txtSdt ";
                        IzDataSource.ParametersAdd("txtSdt", txtSdt.Text);
                    }
                    if (txtEdt.Text != "")
                    {
                        SqlStr += " and tbFbkCdt <= @txtEdt ";
                        IzDataSource.ParametersAdd("txtEdt", txtEdt.Text);
                    }
                    if (selTyp.SelectedValue != "")
                    {
                        SqlStr += " and tbFbkStu = @selTyp ";
                        IzDataSource.ParametersAdd("selTyp", selTyp.SelectedValue);
                    }



                    //'排序
                    String OrderBy = "tbFbkCdt desc"; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;

            case "ADD": //'新增畫面
                {
                    ltStuTitle.Text = "新增";

                    txttbFbkCde.Text = "NEW"; //+ cfg.getcde("FBK");
                    txttbFbkNme.Text = "";
                    //txttbFbkSex.Text = "";
                    WebFormBase.GenRdoList(txttbFbkSex, cfg.SexNmeArr, cfg.SexNmeArr, cfg.SexNmeArr[0]);

                    txttbFbkCty.Text = "";
                    txttbFbkCom.Text = "";
                    txttbFbkTel.Text = "";
                    txttbFbkEml.Text = "";
                    txttbFbkCon.Text = "";
                    //txttbFbkChk.Text = "";
                    WebFormBase.GenRdoList(txttbFbkChk, cfg.FlgNmeArr, cfg.FlgValArr, "0");
                    //txttbFbkStu.Text = "";
                    System.Data.DataTable tbFTP = cfg.getTypLst("FTP");
                    String[] FTPtxt = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypSub", false);
                    String[] FTPval = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypTid", false);
                    WebFormBase.GenRdoList(txttbFbkStu, FTPtxt, FTPval, "FTP001");
                    tbFTP.Dispose();

                    txttbFbkRon.Text = "";
                    //txttbFbkFlg.Text = "";
                    WebFormBase.GenRdoList(txttbFbkFlg, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    txttbFbkCdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbFbkMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbFbkCid.Text = LoginUsr.UsrCde;
                    txttbFbkMid.Text = "";
                    txttbFbkCip.Text = Context.Request.UserHostAddress;
                    txttbFbkMip.Text = "";


                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"

                }
                break;

            case "ADDSAV": //'新增存檔
                {
                    //'取HTML編輯模組傳回值
                    //'String tbUsrAre = Context.Request.Params["ctl00$ContentPlaceHolder1$txttbUsrAre_A"].ToString();

                    //String tbFbkCde = txttbFbkCde.Text;
                    String tbFbkNme = txttbFbkNme.Text;
                    String tbFbkSex = txttbFbkSex.Text;
                    String tbFbkCty = txttbFbkCty.Text;
                    String tbFbkCom = txttbFbkCom.Text;
                    String tbFbkTel = txttbFbkTel.Text;
                    String tbFbkEml = txttbFbkEml.Text;
                    String tbFbkCon = txttbFbkCon.Text;
                    String tbFbkChk = txttbFbkChk.Text;
                    String tbFbkStu = txttbFbkStu.Text;
                    String tbFbkRon = txttbFbkRon.Text;
                    String tbFbkFlg = txttbFbkFlg.Text;
                    String tbFbkCdt = txttbFbkCdt.Text;
                    String tbFbkMdt = txttbFbkMdt.Text;
                    String tbFbkCid = txttbFbkCid.Text;
                    String tbFbkMid = txttbFbkMid.Text;
                    String tbFbkCip = txttbFbkCip.Text;
                    String tbFbkMip = txttbFbkMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.InsertCommand = "insert into tbFbk("
                    + "tbFbkNme"
                    + ",tbFbkSex"
                    + ",tbFbkCty"
                    + ",tbFbkCom"
                    + ",tbFbkTel"
                    + ",tbFbkEml"
                    + ",tbFbkCon"
                    + ",tbFbkChk"
                    + ",tbFbkStu"
                    + ",tbFbkRon"
                    + ",tbFbkFlg"
                    + ",tbFbkCdt"
                    + ",tbFbkMdt"
                    + ",tbFbkCid"
                    + ",tbFbkMid"
                    + ",tbFbkCip"
                    + ",tbFbkMip"
                    + ") values("
                    + "@tbFbkNme"
                    + ",@tbFbkSex"
                    + ",@tbFbkCty"
                    + ",@tbFbkCom"
                    + ",@tbFbkTel"
                    + ",@tbFbkEml"
                    + ",@tbFbkCon"
                    + ",@tbFbkChk"
                    + ",@tbFbkStu"
                    + ",@tbFbkRon"
                    + ",@tbFbkFlg"
                    + ",@tbFbkCdt"
                    + ",@tbFbkMdt"
                    + ",@tbFbkCid"
                    + ",@tbFbkMid"
                    + ",@tbFbkCip"
                    + ",@tbFbkMip"
                    + ")";
                    //IzDataSource.InsertParameters.Add("tbFbkCde", tbFbkCde);
                    IzDataSource.InsertParameters.Add("tbFbkNme", tbFbkNme);
                    IzDataSource.InsertParameters.Add("tbFbkSex", tbFbkSex);
                    IzDataSource.InsertParameters.Add("tbFbkCty", tbFbkCty);
                    IzDataSource.InsertParameters.Add("tbFbkCom", tbFbkCom);
                    IzDataSource.InsertParameters.Add("tbFbkTel", tbFbkTel);
                    IzDataSource.InsertParameters.Add("tbFbkEml", tbFbkEml);
                    IzDataSource.InsertParameters.Add("tbFbkCon", tbFbkCon);
                    IzDataSource.InsertParameters.Add("tbFbkChk", tbFbkChk);
                    IzDataSource.InsertParameters.Add("tbFbkStu", tbFbkStu);
                    IzDataSource.InsertParameters.Add("tbFbkRon", tbFbkRon);
                    IzDataSource.InsertParameters.Add("tbFbkFlg", tbFbkFlg);
                    IzDataSource.InsertParameters.Add("tbFbkCdt", tbFbkCdt);
                    IzDataSource.InsertParameters.Add("tbFbkMdt", tbFbkMdt);
                    IzDataSource.InsertParameters.Add("tbFbkCid", tbFbkCid);
                    IzDataSource.InsertParameters.Add("tbFbkMid", tbFbkMid);
                    IzDataSource.InsertParameters.Add("tbFbkCip", tbFbkCip);
                    IzDataSource.InsertParameters.Add("tbFbkMip", tbFbkMip);

                    IzDataSource.Insert();
                    IzDataSource.Dispose();
                }
                break;

            case "EDIT": //'修改畫面
                {
                    ltStuTitle.Text = "修改";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbFbk where tbFbkCde=@tbFbkCde";
                    IzDataSource.ParametersAdd("tbFbkCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        txttbFbkCde.Text = tb.Rows[0]["tbFbkCde"].ToString();
                        txttbFbkNme.Text = tb.Rows[0]["tbFbkNme"].ToString();
                        //txttbFbkSex.Text = tb.Rows[0]["tbFbkSex"].ToString();
                        WebFormBase.GenRdoList(txttbFbkSex, cfg.SexNmeArr, cfg.SexNmeArr, tb.Rows[0]["tbFbkSex"].ToString());
                        txttbFbkCty.Text = tb.Rows[0]["tbFbkCty"].ToString();
                        txttbFbkCom.Text = tb.Rows[0]["tbFbkCom"].ToString();
                        txttbFbkTel.Text = tb.Rows[0]["tbFbkTel"].ToString();
                        txttbFbkEml.Text = tb.Rows[0]["tbFbkEml"].ToString();
                        txttbFbkCon.Text = tb.Rows[0]["tbFbkCon"].ToString();
                        //txttbFbkChk.Text = tb.Rows[0]["tbFbkChk"].ToString();
                        WebFormBase.GenRdoList(txttbFbkChk, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbFbkChk"].ToString());
                        //txttbFbkStu.Text = tb.Rows[0]["tbFbkStu"].ToString();
                        System.Data.DataTable tbFTP = cfg.getTypLst("FTP");
                        String[] FTPtxt = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypSub", false);
                        String[] FTPval = WebFormBase.GenRdoChkListItemArr(tbFTP, "tbTypTid", false);
                        WebFormBase.GenRdoList(txttbFbkStu, FTPtxt, FTPval, tb.Rows[0]["tbFbkStu"].ToString());
                        tbFTP.Dispose();

                        txttbFbkRon.Text = tb.Rows[0]["tbFbkRon"].ToString();
                        //txttbFbkFlg.Text = tb.Rows[0]["tbFbkFlg"].ToString();
                        WebFormBase.GenRdoList(txttbFbkFlg, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbFbkFlg"].ToString());
                        txttbFbkCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbFbkCdt"]).ToString("yyyy/MM/dd HH:mm:ss");
                        txttbFbkMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        txttbFbkCid.Text = tb.Rows[0]["tbFbkCid"].ToString();
                        txttbFbkMid.Text = LoginUsr.UsrCde;
                        txttbFbkCip.Text = tb.Rows[0]["tbFbkCip"].ToString();
                        txttbFbkMip.Text = Context.Request.UserHostAddress;

                    }
                    tb.Dispose();

                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"


                }
                break;

            case "EDITSAV": //'修改存檔
                {

                    String tbFbkCde = txttbFbkCde.Text;
                    String tbFbkNme = txttbFbkNme.Text;
                    String tbFbkSex = txttbFbkSex.Text;
                    String tbFbkCty = txttbFbkCty.Text;
                    String tbFbkCom = txttbFbkCom.Text;
                    String tbFbkTel = txttbFbkTel.Text;
                    String tbFbkEml = txttbFbkEml.Text;
                    String tbFbkCon = txttbFbkCon.Text;
                    String tbFbkChk = txttbFbkChk.Text;
                    String tbFbkStu = txttbFbkStu.Text;
                    String tbFbkRon = txttbFbkRon.Text;
                    String tbFbkFlg = txttbFbkFlg.Text;
                    String tbFbkCdt = txttbFbkCdt.Text;
                    String tbFbkMdt = txttbFbkMdt.Text;
                    String tbFbkCid = txttbFbkCid.Text;
                    String tbFbkMid = txttbFbkMid.Text;
                    String tbFbkCip = txttbFbkCip.Text;
                    String tbFbkMip = txttbFbkMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.UpdateCommand = "update tbFbk set "
                    + "tbFbkNme=@tbFbkNme"
                    + ",tbFbkSex=@tbFbkSex"
                    + ",tbFbkCty=@tbFbkCty"
                    + ",tbFbkCom=@tbFbkCom"
                    + ",tbFbkTel=@tbFbkTel"
                    + ",tbFbkEml=@tbFbkEml"
                    + ",tbFbkCon=@tbFbkCon"
                    + ",tbFbkChk=@tbFbkChk"
                    + ",tbFbkStu=@tbFbkStu"
                    + ",tbFbkRon=@tbFbkRon"
                    + ",tbFbkFlg=@tbFbkFlg"
                    + ",tbFbkCdt=@tbFbkCdt"
                    + ",tbFbkMdt=@tbFbkMdt"
                    + ",tbFbkCid=@tbFbkCid"
                    + ",tbFbkMid=@tbFbkMid"
                    + ",tbFbkCip=@tbFbkCip"
                    + ",tbFbkMip=@tbFbkMip"
                    + " where tbFbkCde=@tbFbkCde";
                    IzDataSource.UpdateParameters.Add("tbFbkCde", tbFbkCde);
                    IzDataSource.UpdateParameters.Add("tbFbkNme", tbFbkNme);
                    IzDataSource.UpdateParameters.Add("tbFbkSex", tbFbkSex);
                    IzDataSource.UpdateParameters.Add("tbFbkCty", tbFbkCty);
                    IzDataSource.UpdateParameters.Add("tbFbkCom", tbFbkCom);
                    IzDataSource.UpdateParameters.Add("tbFbkTel", tbFbkTel);
                    IzDataSource.UpdateParameters.Add("tbFbkEml", tbFbkEml);
                    IzDataSource.UpdateParameters.Add("tbFbkCon", tbFbkCon);
                    IzDataSource.UpdateParameters.Add("tbFbkChk", tbFbkChk);
                    IzDataSource.UpdateParameters.Add("tbFbkStu", tbFbkStu);
                    IzDataSource.UpdateParameters.Add("tbFbkRon", tbFbkRon);
                    IzDataSource.UpdateParameters.Add("tbFbkFlg", tbFbkFlg);
                    IzDataSource.UpdateParameters.Add("tbFbkCdt", tbFbkCdt);
                    IzDataSource.UpdateParameters.Add("tbFbkMdt", tbFbkMdt);
                    IzDataSource.UpdateParameters.Add("tbFbkCid", tbFbkCid);
                    IzDataSource.UpdateParameters.Add("tbFbkMid", tbFbkMid);
                    IzDataSource.UpdateParameters.Add("tbFbkCip", tbFbkCip);
                    IzDataSource.UpdateParameters.Add("tbFbkMip", tbFbkMip);

                    IzDataSource.Update();
                    IzDataSource.Dispose();
                }
                break;

            case "DELALL": //'多選刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    String SelT = Context.Request.Params["chkSelT"].ToString();
                    String[] SelTArr = SelT.Split(',');
                    for (int i = 0; i < SelTArr.Length; i++)
                    {

                        //'刪除
                        IzDataSource.DeleteCommand = "delete from tbFbk where tbFbkCde=@tbFbkCde";
                        IzDataSource.DeleteParameters.Clear();
                        IzDataSource.DeleteParameters.Add("tbFbkCde", SelTArr[i]);
                        IzDataSource.Delete();

                    }

                    IzDataSource.Dispose();
                }
                break;

            case "DELONE": //'單筆刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    //'刪除
                    IzDataSource.DeleteCommand = "delete from tbFbk where tbFbkCde=@tbFbkCde";
                    IzDataSource.DeleteParameters.Clear();
                    IzDataSource.DeleteParameters.Add("tbFbkCde", CDE);
                    IzDataSource.Delete();

                    IzDataSource.Dispose();
                }
                break;
            case "VIEW": //'單筆檢視
                {
                    ltStuTitle.Text = "檢視";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbFbk where tbFbkCde=@tbFbkCde";
                    IzDataSource.ParametersAdd("tbFbkCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        lbtbFbkCde.Text = tb.Rows[0]["tbFbkCde"].ToString();
                        lbtbFbkNme.Text = tb.Rows[0]["tbFbkNme"].ToString();
                        lbtbFbkSex.Text = tb.Rows[0]["tbFbkSex"].ToString();
                        lbtbFbkCty.Text = tb.Rows[0]["tbFbkCty"].ToString();
                        lbtbFbkCom.Text = tb.Rows[0]["tbFbkCom"].ToString();
                        lbtbFbkTel.Text = tb.Rows[0]["tbFbkTel"].ToString();
                        lbtbFbkEml.Text = tb.Rows[0]["tbFbkEml"].ToString();
                        lbtbFbkCon.Text = tb.Rows[0]["tbFbkCon"].ToString();
                        lbtbFbkChk.Text = cfg.getFlgNme(tb.Rows[0]["tbFbkChk"].ToString());
                        lbtbFbkStu.Text = cfg.getTypSub("FTP", tb.Rows[0]["tbFbkStu"].ToString());
                        lbtbFbkRon.Text = tb.Rows[0]["tbFbkRon"].ToString();
                        lbtbFbkFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbFbkFlg"].ToString());
                        lbtbFbkCdt.Text = tb.Rows[0]["tbFbkCdt"].ToString();
                        lbtbFbkMdt.Text = tb.Rows[0]["tbFbkMdt"].ToString();
                        lbtbFbkCid.Text = tb.Rows[0]["tbFbkCid"].ToString();
                        lbtbFbkMid.Text = tb.Rows[0]["tbFbkMid"].ToString();
                        lbtbFbkCip.Text = tb.Rows[0]["tbFbkCip"].ToString();
                        lbtbFbkMip.Text = tb.Rows[0]["tbFbkMip"].ToString();

                    }
                    tb.Dispose();
                }
                break;

            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                UPDATE.Visible = false;
                VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;
            case "ADD": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','ADDSAV');";
                //'ADD返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "EDIT": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','EDITSAV');";
                //'EDIT返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "VIEW": //'檢視狀態
                LIST.Visible = false;
                UPDATE.Visible = false;
                VIEW.Visible = true;

                //'VIEW返回按鈕
                lnViewBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbFbk where tbFbkCde='" + dr["tbFbkCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                Label lbXtbFbkCde = (Label)e.Item.FindControl("lbXtbFbkCde"); //tbFbkCde
                Label lbXtbFbkNme = (Label)e.Item.FindControl("lbXtbFbkNme"); //tbFbkNme
                //Label lbXtbFbkSex = (Label)e.Item.FindControl("lbXtbFbkSex"); //tbFbkSex
                Label lbXtbFbkCty = (Label)e.Item.FindControl("lbXtbFbkCty"); //tbFbkCty
                //Label lbXtbFbkCom = (Label)e.Item.FindControl("lbXtbFbkCom"); //tbFbkCom
                //Label lbXtbFbkTel = (Label)e.Item.FindControl("lbXtbFbkTel"); //tbFbkTel
                //Label lbXtbFbkEml = (Label)e.Item.FindControl("lbXtbFbkEml"); //tbFbkEml
                Label lbXtbFbkCon = (Label)e.Item.FindControl("lbXtbFbkCon"); //tbFbkCon
                //Label lbXtbFbkChk = (Label)e.Item.FindControl("lbXtbFbkChk"); //tbFbkChk
                Label lbXtbFbkStu = (Label)e.Item.FindControl("lbXtbFbkStu"); //tbFbkStu
                //Label lbXtbFbkRon = (Label)e.Item.FindControl("lbXtbFbkRon"); //tbFbkRon
                Label lbXtbFbkFlg = (Label)e.Item.FindControl("lbXtbFbkFlg"); //tbFbkFlg
                Label lbXtbFbkCdt = (Label)e.Item.FindControl("lbXtbFbkCdt"); //tbFbkCdt

                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                lbXtbFbkCde.Text = tb.Rows[0]["tbFbkCde"].ToString();
                lbXtbFbkNme.Text = tb.Rows[0]["tbFbkNme"].ToString();
                //lbXtbFbkSex.Text = tb.Rows[0]["tbFbkSex"].ToString();
                lbXtbFbkCty.Text = tb.Rows[0]["tbFbkCty"].ToString();
                //lbXtbFbkCom.Text = tb.Rows[0]["tbFbkCom"].ToString();
                //lbXtbFbkTel.Text = tb.Rows[0]["tbFbkTel"].ToString();
                //lbXtbFbkEml.Text = tb.Rows[0]["tbFbkEml"].ToString();
                lbXtbFbkCon.Text = "<font size=2>" + tb.Rows[0]["tbFbkCon"].ToString() + "</font>";
                //lbXtbFbkChk.Text = tb.Rows[0]["tbFbkChk"].ToString();
                lbXtbFbkStu.Text = cfg.getTypSub("FTP", tb.Rows[0]["tbFbkStu"].ToString());
                //lbXtbFbkRon.Text = tb.Rows[0]["tbFbkRon"].ToString();
                lbXtbFbkFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbFbkFlg"].ToString());
                lbXtbFbkCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbFbkCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbFbkCdt"]).ToString("HH:mm:ss");

                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbFbkCde"].ToString() + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbFbkCde"].ToString() + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbFbkCde"].ToString() + "','" + tb.Rows[0]["tbFbkNme"].ToString() + "')";

            }
            tb.Dispose();
            IzDataSource.Dispose();
        }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }


    protected void bntExl_Click(object sender, EventArgs e)
    {
        IzDataSource IzDataSource = new IzDataSource();
        IzDataSource.ParametersClear();


        //'設定基本語法
        String SqlStr = "select * from tbFbk where 1=1 ";

        if (txtWhat.Text != "")
        {
            if (SelItem.SelectedValue == "ALL")
            {
                SqlStr += " and (tbFbkNme like @tbFbkNmeA or tbFbkSex like @tbFbkSexA or tbFbkCty like @tbFbkCtyA or tbFbkCom like @tbFbkComA or tbFbkTel like @tbFbkTelA or tbFbkEml like @tbFbkEmlA or tbFbkCon like @tbFbkConA or tbFbkStu like @tbFbkStuA or tbFbkRon like @tbFbkRonA or tbFbkCde like @tbFbkCdeA)";
                IzDataSource.ParametersAdd("tbFbkNmeA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkSexA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkCtyA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkComA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkTelA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkEmlA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkConA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkStuA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkRonA", "%" + txtWhat.Text + "%");
                IzDataSource.ParametersAdd("tbFbkCdeA", "%" + txtWhat.Text + "%");
            }
            else
            {
                SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
            }
        }

        if (txtSdt.Text != "")
        {
            SqlStr += " and tbFbkCdt >= @txtSdt ";
            IzDataSource.ParametersAdd("txtSdt", txtSdt.Text);
        }
        if (txtEdt.Text != "")
        {
            SqlStr += " and tbFbkCdt <= @txtEdt ";
            IzDataSource.ParametersAdd("txtEdt", txtEdt.Text);
        }
        if (selTyp.SelectedValue != "")
        {
            SqlStr += " and tbFbkStu = @selTyp ";
            IzDataSource.ParametersAdd("selTyp", selTyp.SelectedValue);
        }



        //'排序
        String OrderBy = " order by tbFbkCdt desc"; //'基本排序

        SqlStr += OrderBy;


        //'設定查詢字串
        IzDataSource.SelectString = SqlStr;
        System.Data.DataTable tbS = IzDataSource.SelectDataTable();

        //'取得資料結果
        String[] FdArr = { "回饋編號", "姓名", "性別", "所在縣市", "公司或機構", "電話", "Email", "問題或建議", "處理狀態", "處理紀錄" };
        String[] FdnmeArr = { "tbFbkCde", "tbFbkNme", "tbFbkSex", "tbFbkCty", "tbFbkCom", "tbFbkTel", "tbFbkEml", "tbFbkCon", "tbFbkStu", "tbFbkRon" };


        System.Data.DataTable tb = new System.Data.DataTable();
        for (int i = 0; i < FdArr.Length; i++)
        {
            tb.Columns.Add(FdArr[i]);
        }


        for (int j = 0; j < tbS.Rows.Count; j++)
        {

            tb.Rows.Add(tb.NewRow());// '新增一筆

            for (int i = 0; i < FdArr.Length; i++)
            {
                if (FdnmeArr[i] == "tbFbkStu")
                {
                    tb.Rows[j][FdArr[i]] =cfg.getTypSub("FTP", tbS.Rows[j][FdnmeArr[i]].ToString());
                }
                else {
                    tb.Rows[j][FdArr[i]] = tbS.Rows[j][FdnmeArr[i]].ToString();
                }
                
            }


        }


       System.Web.UI .WebControls .DataGrid DataGrid1=new  System.Web.UI .WebControls .DataGrid();


       DataGrid1.DataSource = tb;
       DataGrid1.DataBind();


        Response.Buffer = true;
        Response.ContentType = "application/vnd.ms-excel";
        String l_Date;
        l_Date = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
        Response.AddHeader("content-disposition", "attachment; filename=" + l_Date + ".xls");
        //'Response.ContentType = "application/vnd.ms-excel"
        if (chkUTF8.Checked == true)
        {
            Response.ContentEncoding = System.Text.Encoding.UTF8;
        }
        else {
            Response.ContentEncoding = System.Text.Encoding.Default;
        }
      

        Response.Write("<style>td{mso-number-format:\"\\@\";}</style>");
        System.IO.StringWriter tw = new System.IO.StringWriter();
        HtmlTextWriter hw = new HtmlTextWriter(tw);
        DataGrid1.RenderControl(hw);

        Response.Write(tw.ToString());

        Response.End();



    }
}