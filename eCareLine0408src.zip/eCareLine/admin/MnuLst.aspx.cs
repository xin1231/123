﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_MnuLst : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10000;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    String TOPCDE = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_TOPCDE"] != null) TOPCDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_TOPCDE"].ToString()); //'目前資料上層編號


        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbMnuCde from tbMnu where (tbMnuTopCde is null or tbMnuTopCde='') ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = "tbMnuSrt"; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;

            case "ADD": //'新增畫面
                {
                    ltStuTitle.Text = "新增";

                    IzDataSource IzDataSource = new IzDataSource();
                    System.Data.SqlClient.SqlConnection Conn = IzDataSource.OpenConn();
                    IzDataSource.Dispose();

                    txttbMnuCde.Text = "" + cfg.getcde("MNU");
                    //txttbMnuTopCde.Text = "";
                    txttbMnuTopCde.Items.Clear();
                    String Tmp = DataAccess.SqlGenListItemFromTbRc(Conn, "tbMnu", "tbMnuFlg=1", "tbMnuTopCde", "tbMnuCde", "tbMnuSub", "tbMnuSrt", "", "頂層", "∟");
                    String[] TmpArr = Tmp.Split(',');
                    for (int i = 0; i < TmpArr.Length; i++)
                    {
                        String[] TmpArrA = TmpArr[i].Split(':');
                        ListItem lt = new ListItem();
                        lt.Text = TmpArrA[0];
                        lt.Value = TmpArrA[1];
                        if (TmpArrA[1] == TOPCDE)
                        {
                            lt.Selected = true;
                        }
                        txttbMnuTopCde.Items.Add(lt);
                    }
                    txttbMnuSub.Text = "";
                    txttbMnuCon.Text = "";
                    //txttbMnuTyp.Text = "";
                    WebFormBase.GenRdoList(txttbMnuTyp, mnuDA.MnuTypNmeArr, mnuDA.MnuTypValArr, "1");
                    txttbMnuUrl.Text = "";
                    txttbMnuSrt.Text = cfg.getNextSrt("tbMnu", "tbMnuSrt").ToString();
                    //txttbMnuFlg.Text = "";
                    WebFormBase.GenRdoList(txttbMnuFlg, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    txttbMnuCdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbMnuMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbMnuCid.Text = LoginUsr.UsrCde;
                    txttbMnuMid.Text = "";
                    txttbMnuCip.Text = Context.Request.UserHostAddress;
                    txttbMnuMip.Text = "";


                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"

                }
                break;

            case "ADDSAV": //'新增存檔
                {
                    //'取HTML編輯模組傳回值
                    //'String tbUsrAre = Context.Request.Params["ctl00$ContentPlaceHolder1$txttbUsrAre_A"].ToString();

                    String tbMnuCde = txttbMnuCde.Text;
                    String tbMnuTopCde = txttbMnuTopCde.SelectedValue;
                    String tbMnuSub = txttbMnuSub.Text;
                    String tbMnuCon = txttbMnuCon.Text;
                    String tbMnuTyp = txttbMnuTyp.Text;
                    String tbMnuUrl = txttbMnuUrl.Text;
                    String tbMnuSrt = txttbMnuSrt.Text;
                    String tbMnuFlg = txttbMnuFlg.Text;
                    String tbMnuCdt = txttbMnuCdt.Text;
                    String tbMnuMdt = txttbMnuMdt.Text;
                    String tbMnuCid = txttbMnuCid.Text;
                    String tbMnuMid = txttbMnuMid.Text;
                    String tbMnuCip = txttbMnuCip.Text;
                    String tbMnuMip = txttbMnuMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.InsertCommand = "insert into tbMnu("
                    + "tbMnuCde"
                    + ",tbMnuTopCde"
                    + ",tbMnuSub"
                    + ",tbMnuCon"
                    + ",tbMnuTyp"
                    + ",tbMnuUrl"
                    + ",tbMnuSrt"
                    + ",tbMnuFlg"
                    + ",tbMnuCdt"
                    + ",tbMnuMdt"
                    + ",tbMnuCid"
                    + ",tbMnuMid"
                    + ",tbMnuCip"
                    + ",tbMnuMip"
                    + ") values("
                    + "@tbMnuCde"
                    + ",@tbMnuTopCde"
                    + ",@tbMnuSub"
                    + ",@tbMnuCon"
                    + ",@tbMnuTyp"
                    + ",@tbMnuUrl"
                    + ",@tbMnuSrt"
                    + ",@tbMnuFlg"
                    + ",@tbMnuCdt"
                    + ",@tbMnuMdt"
                    + ",@tbMnuCid"
                    + ",@tbMnuMid"
                    + ",@tbMnuCip"
                    + ",@tbMnuMip"
                    + ")";
                    IzDataSource.InsertParameters.Add("tbMnuCde", tbMnuCde);
                    IzDataSource.InsertParameters.Add("tbMnuTopCde", tbMnuTopCde);
                    IzDataSource.InsertParameters.Add("tbMnuSub", tbMnuSub);
                    IzDataSource.InsertParameters.Add("tbMnuCon", tbMnuCon);
                    IzDataSource.InsertParameters.Add("tbMnuTyp", tbMnuTyp);
                    IzDataSource.InsertParameters.Add("tbMnuUrl", tbMnuUrl);
                    IzDataSource.InsertParameters.Add("tbMnuSrt", tbMnuSrt);
                    IzDataSource.InsertParameters.Add("tbMnuFlg", tbMnuFlg);
                    IzDataSource.InsertParameters.Add("tbMnuCdt", tbMnuCdt);
                    IzDataSource.InsertParameters.Add("tbMnuMdt", tbMnuMdt);
                    IzDataSource.InsertParameters.Add("tbMnuCid", tbMnuCid);
                    IzDataSource.InsertParameters.Add("tbMnuMid", tbMnuMid);
                    IzDataSource.InsertParameters.Add("tbMnuCip", tbMnuCip);
                    IzDataSource.InsertParameters.Add("tbMnuMip", tbMnuMip);

                    IzDataSource.Insert();
                    IzDataSource.Dispose();
                }
                break;

            case "EDIT": //'修改畫面
                {
                    ltStuTitle.Text = "修改";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbMnu where tbMnuCde=@tbMnuCde";
                    IzDataSource.ParametersAdd("tbMnuCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    System.Data.SqlClient.SqlConnection Conn = IzDataSource.OpenConn();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        txttbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                        //txttbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                        txttbMnuTopCde.Items.Clear();
                        String Tmp = DataAccess.SqlGenListItemFromTbRc(Conn, "tbMnu", "tbMnuFlg=1", "tbMnuTopCde", "tbMnuCde", "tbMnuSub", "tbMnuSrt", "", "頂層", "∟");
                        String[] TmpArr = Tmp.Split(',');
                        for (int i = 0; i < TmpArr.Length; i++)
                        {
                            String[] TmpArrA = TmpArr[i].Split(':');
                            ListItem lt = new ListItem();
                            lt.Text = TmpArrA[0];
                            lt.Value = TmpArrA[1];
                            if (TmpArrA[1] == tb.Rows[0]["tbMnuTopCde"].ToString())
                            {
                                lt.Selected = true;
                            }
                            txttbMnuTopCde.Items.Add(lt);
                        }

                        txttbMnuSub.Text = tb.Rows[0]["tbMnuSub"].ToString();
                        txttbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                        //txttbMnuTyp.Text = tb.Rows[0]["tbMnuTyp"].ToString();
                        WebFormBase.GenRdoList(txttbMnuTyp, mnuDA.MnuTypNmeArr, mnuDA.MnuTypValArr, tb.Rows[0]["tbMnuTyp"].ToString());
                        txttbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                        txttbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                        //txttbMnuFlg.Text = tb.Rows[0]["tbMnuFlg"].ToString();
                        WebFormBase.GenRdoList(txttbMnuFlg, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbMnuFlg"].ToString());
                        txttbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd HH:mm:ss");
                        txttbMnuMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        txttbMnuCid.Text = tb.Rows[0]["tbMnuCid"].ToString();
                        txttbMnuMid.Text = LoginUsr.UsrCde;
                        txttbMnuCip.Text = tb.Rows[0]["tbMnuCip"].ToString();
                        txttbMnuMip.Text = Context.Request.UserHostAddress;

                    }
                    tb.Dispose();

                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"


                }
                break;

            case "EDITSAV": //'修改存檔
                {

                    String tbMnuCde = txttbMnuCde.Text;
                    String tbMnuTopCde = txttbMnuTopCde.SelectedValue;
                    String tbMnuSub = txttbMnuSub.Text;
                    String tbMnuCon = txttbMnuCon.Text;
                    String tbMnuTyp = txttbMnuTyp.Text;
                    String tbMnuUrl = txttbMnuUrl.Text;
                    String tbMnuSrt = txttbMnuSrt.Text;
                    String tbMnuFlg = txttbMnuFlg.Text;
                    String tbMnuCdt = txttbMnuCdt.Text;
                    String tbMnuMdt = txttbMnuMdt.Text;
                    String tbMnuCid = txttbMnuCid.Text;
                    String tbMnuMid = txttbMnuMid.Text;
                    String tbMnuCip = txttbMnuCip.Text;
                    String tbMnuMip = txttbMnuMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.UpdateCommand = "update tbMnu set "
                    + "tbMnuCde=@tbMnuCde"
                    + ",tbMnuTopCde=@tbMnuTopCde"
                    + ",tbMnuSub=@tbMnuSub"
                    + ",tbMnuCon=@tbMnuCon"
                    + ",tbMnuTyp=@tbMnuTyp"
                    + ",tbMnuUrl=@tbMnuUrl"
                    + ",tbMnuSrt=@tbMnuSrt"
                    + ",tbMnuFlg=@tbMnuFlg"
                    + ",tbMnuCdt=@tbMnuCdt"
                    + ",tbMnuMdt=@tbMnuMdt"
                    + ",tbMnuCid=@tbMnuCid"
                    + ",tbMnuMid=@tbMnuMid"
                    + ",tbMnuCip=@tbMnuCip"
                    + ",tbMnuMip=@tbMnuMip"
                    + " where tbMnuCde=@tbMnuCde";
                    IzDataSource.UpdateParameters.Add("tbMnuCde", tbMnuCde);
                    IzDataSource.UpdateParameters.Add("tbMnuTopCde", tbMnuTopCde);
                    IzDataSource.UpdateParameters.Add("tbMnuSub", tbMnuSub);
                    IzDataSource.UpdateParameters.Add("tbMnuCon", tbMnuCon);
                    IzDataSource.UpdateParameters.Add("tbMnuTyp", tbMnuTyp);
                    IzDataSource.UpdateParameters.Add("tbMnuUrl", tbMnuUrl);
                    IzDataSource.UpdateParameters.Add("tbMnuSrt", tbMnuSrt);
                    IzDataSource.UpdateParameters.Add("tbMnuFlg", tbMnuFlg);
                    IzDataSource.UpdateParameters.Add("tbMnuCdt", tbMnuCdt);
                    IzDataSource.UpdateParameters.Add("tbMnuMdt", tbMnuMdt);
                    IzDataSource.UpdateParameters.Add("tbMnuCid", tbMnuCid);
                    IzDataSource.UpdateParameters.Add("tbMnuMid", tbMnuMid);
                    IzDataSource.UpdateParameters.Add("tbMnuCip", tbMnuCip);
                    IzDataSource.UpdateParameters.Add("tbMnuMip", tbMnuMip);

                    IzDataSource.Update();
                    IzDataSource.Dispose();
                }
                break;

            case "DELALL": //'多選刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    String SelT = Context.Request.Params["chkSelT"].ToString();
                    String[] SelTArr = SelT.Split(',');
                    for (int i = 0; i < SelTArr.Length; i++)
                    {

                        //'刪除
                        IzDataSource.DeleteCommand = "delete from tbMnu where tbMnuCde=@tbMnuCde";
                        IzDataSource.DeleteParameters.Clear();
                        IzDataSource.DeleteParameters.Add("tbMnuCde", SelTArr[i]);
                        IzDataSource.Delete();

                    }

                    IzDataSource.Dispose();
                }
                break;

            case "DELONE": //'單筆刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    //'刪除
                    IzDataSource.DeleteCommand = "delete from tbMnu where tbMnuCde=@tbMnuCde";
                    IzDataSource.DeleteParameters.Clear();
                    IzDataSource.DeleteParameters.Add("tbMnuCde", CDE);
                    IzDataSource.Delete();

                    IzDataSource.Dispose();
                }
                break;
            case "VIEW": //'單筆檢視
                {
                    ltStuTitle.Text = "檢視";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbMnu where tbMnuCde=@tbMnuCde";
                    IzDataSource.ParametersAdd("tbMnuCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        lbtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                        lbtbMnuTopCde.Text = mnuDA.getMnuSub(tb.Rows[0]["tbMnuTopCde"].ToString());
                        lbtbMnuSub.Text = tb.Rows[0]["tbMnuSub"].ToString();
                        lbtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                        lbtbMnuTyp.Text = mnuDA.getMnuTypNme(tb.Rows[0]["tbMnuTyp"].ToString());
                        lbtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                        lbtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                        lbtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                        lbtbMnuCdt.Text = tb.Rows[0]["tbMnuCdt"].ToString();
                        lbtbMnuMdt.Text = tb.Rows[0]["tbMnuMdt"].ToString();
                        lbtbMnuCid.Text = tb.Rows[0]["tbMnuCid"].ToString();
                        lbtbMnuMid.Text = tb.Rows[0]["tbMnuMid"].ToString();
                        lbtbMnuCip.Text = tb.Rows[0]["tbMnuCip"].ToString();
                        lbtbMnuMip.Text = tb.Rows[0]["tbMnuMip"].ToString();

                    }
                    tb.Dispose();
                }
                break;

            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                UPDATE.Visible = false;
                VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;
            case "ADD": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','ADDSAV');";
                //'ADD返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "EDIT": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','EDITSAV');";
                //'EDIT返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "VIEW": //'檢視狀態
                LIST.Visible = false;
                UPDATE.Visible = false;
                VIEW.Visible = true;

                //'VIEW返回按鈕
                lnViewBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                HyperLink lnADDB = (HyperLink)e.Item.FindControl("lnADDB"); //'新增次層
                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "<i class=\"fa fa-sun-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text =mnuDA.getMnuTypNme( tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");

                lnADDB.NavigateUrl = "javascript:goADDB('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbMnuCde"] + "','" + tb.Rows[0]["tbMnuSub"].ToString() + "')";

            }
            tb.Dispose();


            Repeater Repeater2 = (Repeater)e.Item.FindControl("Repeater2");
            System.Data.DataTable tb2 = IzDataSource.GenDataTable("select tbMnuCde from tbMnu where tbMnuTopCde='" + dr["tbMnuCde"].ToString() + "' order by tbMnuSrt");
            Repeater2.DataSource = tb2;
            Repeater2.DataBind();

            IzDataSource.Dispose();

        }
    }

    protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                HyperLink lnADDB = (HyperLink)e.Item.FindControl("lnADDB"); //'新增次層
                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "　　<i class=\"fa fa-moon-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text =mnuDA.getMnuTypNme( tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");

                lnADDB.NavigateUrl = "javascript:goADDB('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbMnuCde"] + "','" + tb.Rows[0]["tbMnuSub"].ToString() + "')";

            }
            tb.Dispose();


            Repeater Repeater3 = (Repeater)e.Item.FindControl("Repeater3");
            System.Data.DataTable tb3 = IzDataSource.GenDataTable("select tbMnuCde from tbMnu where tbMnuTopCde='" + dr["tbMnuCde"].ToString() + "' order by tbMnuSrt");
            Repeater3.DataSource = tb3;
            Repeater3.DataBind();

            IzDataSource.Dispose();

        }
    }


    protected void Repeater3_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                HyperLink lnADDB = (HyperLink)e.Item.FindControl("lnADDB"); //'新增次層
                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "　　　　<i class=\"fa fa-star-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text = mnuDA.getMnuTypNme(tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");

                lnADDB.NavigateUrl = "";//"javascript:goADDB('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnADDB.Text = "--";
                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbMnuCde"] + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbMnuCde"] + "','" + tb.Rows[0]["tbMnuSub"].ToString() + "')";

            }
            tb.Dispose();


            IzDataSource.Dispose();

        }
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        Page.ClientScript.RegisterHiddenField("List1_TOPCDE", TOPCDE);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }


}