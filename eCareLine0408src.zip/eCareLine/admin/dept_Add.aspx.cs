﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_dept_Add : System.Web.UI.Page
{
    UpLoadClass1 uf = new UpLoadClass1();
    cfg cfg = new cfg();
    LoginUsr LoginUsr;
    SqlConnection cnn;
    // string myConnectString = @"Server='localhost\SQLEXPRESS'; database='MyDB1';Integrated Security=True;";
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    //綁定DropDownList在後端直接用ADO.NET處理(方式1)(迴圈去read)。
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            txtdept_ID.Text = cfg.getcde("DEP");
        }
    }

    protected void btnDeptAdd_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();

            string commString = "INSERT INTO tbDept (dept_ID, dept_Name, dep_Notes) ";
            commString += " VALUES (@depID, @depName, @depNotes)";
            SqlCommand myComm = new SqlCommand(commString, cnn);

            myComm.Parameters.AddWithValue("@depID", txtdept_ID.Text);
            myComm.Parameters.AddWithValue("@depName", txtName.Text);
            myComm.Parameters.AddWithValue("@depNotes", txtNotes.Text);

            // Response.Write("<p>存檔前程式</p>");
            myComm.ExecuteNonQuery();
            // 
            Response.Write("<p>存檔程式成功</p>");

            // MessageBox.Show(this, "新增成功!");
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            // MessageBox.Show(this, ex.Message);
        }
    }
}