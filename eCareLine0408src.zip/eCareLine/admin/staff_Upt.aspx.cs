﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
public partial class admin_staff_Upt : System.Web.UI.Page
{
    SqlConnection cnn;
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    protected void Page_Load(object sender, EventArgs e)
    {
        string ID;
        if (!IsPostBack)
        {
            ID = Request.QueryString["staID"];
            bindMyListBoxData();
            ListBox1.SelectedValue = ID;
            DisPlayStaff(ID);
        }

    }
    protected void bindMyListBoxData()
    {
        string ds = myConnectString;
        SqlConnection conn = new SqlConnection(ds);
        SqlDataReader dr = null;
        string dc = "select staff_ID from tbStaff ";
        SqlCommand cmd = new SqlCommand(dc, conn);
        conn.Open();
        dr = cmd.ExecuteReader();
        while (dr.Read())
        {
            ListBox1.Items.Add(new ListItem(dr["staff_ID"].ToString()));
        }
        cmd.Cancel();
        dr.Close();
        conn.Close();
        conn.Dispose();

/*
        str = "select * from employee"
  com = New SqlCommand(str, con)
  sqlda = New SqlDataAdapter(com)
  ds = New DataSet
  sqlda.Fill(ds, "employee")
  ListBox1.DataValueField = "empid"
  ListBox1.DataTextField = "empname"
  ListBox1.DataSource = ds
  ListBox1.DataMember = "employee"
  ListBox1.DataBind()
  con.Close()
        ListBox1.DisplayMember = "staff_ID"; //ColumnName is what text to display in listBox
*/
    }

    protected void DisPlayStaff(string ID)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "tbStaff";
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.Parameters.AddWithValue("@code", ID);
            cmd.CommandText = "SELECT * FROM " + tbName + " ";
            cmd.CommandText += "WHERE staff_ID = @code";
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();

            lbResult.Text = "<table border=1>";
            while (myDR.Read())
            {
                lbResult.Text += "<tr>";
                for (int i = 0; i < myDR.FieldCount; i++)
                {
                    //判斷圖片檔案欄位
                    if (myDR.GetName(i).ToString() == "staff_PhotoFileName")
                    {
                        lbResult.Text += "<td>";
                        lbResult.Text += "<img src=" + myDR[i].ToString() + " width=150>";
                        lbResult.Text += "</td>";
                    }
                    else
                    {
                        lbResult.Text += "<td>" + myDR[i].ToString() + "</td>";
                    }
                }
                lbResult.Text += "</tr>";
            }
            lbResult.Text += "</table>";

            cnn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void btnUptPhoto_Click(object sender, EventArgs e)
    {
        myUploadFile();
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "tbStaff";
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.Parameters.AddWithValue("code", ListBox1.SelectedValue);
            cmd.Parameters.AddWithValue("FileName", photoFileName);
            cmd.Parameters.AddWithValue("Name", txtName.Text);
            cmd.CommandText = "UPDATE " + tbName + " SET ";
            cmd.CommandText += "staff_PhotoFileName = @FileName";
            cmd.CommandText += ", staff_Name = @Name";
            cmd.CommandText += " WHERE staff_ID  = @code ";

            cmd.ExecuteNonQuery();

            cnn.Close();
            Response.Write("<p>更新成功!</p>");
            // 顯示更新結果
            DisPlayStaff(ListBox1.SelectedValue);
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
    string photoFileName;
    protected void myUploadFile()
    {
        try
        {
            string folderPath = Server.MapPath("Uploads/");
            Response.Write(folderPath);
            //Check whether Directory (Folder) exists.
            if (!Directory.Exists(folderPath))
            {
                //If Directory (Folder) does not exists Create it.
                Directory.CreateDirectory(folderPath);
            }
            // 判斷 Server 上檔案名稱是否有重覆情況，有的話必須進行更名
            // 使用 Path.Combine 來集合路徑的優點
            //  以前發生過儲存 Table 內的是 \\ServerName\Dir（最後面沒有 \ 符號），
            //  直接跟 FileName 來進行結合，會變成 \\ServerName\DirFileName 的情況，
            //  資料夾路徑的最後面有沒有 \ 符號變成還需要判斷，但用 Path.Combine 來結合的話，
            //  資料夾路徑沒有 \ 符號，會自動補上，有的話，就直接結合
            string filename = FU1.FileName;
            string extension = Path.GetExtension(filename).ToLowerInvariant();
            // 絶對路徑+檔名
            string serverFilePath = Path.Combine(folderPath, filename);
            string fileNameOnly = Path.GetFileNameWithoutExtension(filename);
            int fileCount = 1;
            while (File.Exists(serverFilePath))
            {
                // 重覆檔案的命名規則為 檔名_1、檔名_2 以此類推
                filename = string.Concat(fileNameOnly, "_", fileCount, extension);
                serverFilePath = Path.Combine(folderPath, filename);
                fileCount++;
            }
            //Save the File to the Directory (Folder).
            // FU1.SaveAs(folderPath + Path.GetFileName(FU1.FileName));
            FU1.SaveAs(serverFilePath);
            photoFileName = "Uploads/" + filename;
            //Display the Picture in Image control.
            imgPhoto.ImageUrl = photoFileName;
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
            // MessageBox.Show(this, ex.Message);
        }

    }
    protected void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        DisPlayStaff(ListBox1.SelectedValue);
    }
}