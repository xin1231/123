﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_StoLst : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbStoCde from tbSto where 1=1 ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = "tbStoCdt desc"; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;

            case "ADD": //'新增畫面
                {
                    ltStuTitle.Text = "新增";

                    txttbStoCde.Text = "" + cfg.getcde("STO");
                    //txttbStoTyp.Text = "";
                    System.Data.DataTable tbNTP = cfg.getTypLst("NTP");
                    String[] NTPtxt = WebFormBase.GenRdoChkListItemArr(tbNTP, "tbTypSub", true);
                    NTPtxt[0] = "請選擇";
                    String[] NTPval = WebFormBase.GenRdoChkListItemArr(tbNTP, "tbTypTid", true);
                    WebFormBase.GenDropDownListItem(txttbStoTyp, NTPtxt, NTPval, "");
                    tbNTP.Dispose();

                    txttbStoSub.Text = "";
                    txttbStoCon.Text = "";
                    txttbStoPdt.Text = DateTime.Now.ToString("yyyy-MM-dd");
                    txttbStoPdt.Attributes.Add("type", "date");
                    //txttbStoPdt.Attributes["onclick"] = "showCalendar(this, this, 'yyyy/mm/dd','tw',1)";
                    //txttbStoTop.Text = "";
                    WebFormBase.GenRdoList(txttbStoTop, cfg.FlgNmeArr, cfg.FlgValArr, "0");
                    //txttbStoFbs.Text = "";
                    WebFormBase.GenRdoList(txttbStoFbs, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    //txttbStoFlg.Text = "";
                    WebFormBase.GenRdoList(txttbStoFlg, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    txttbStoCdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbStoMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbStoCid.Text = LoginUsr.UsrCde;
                    txttbStoMid.Text = "";
                    txttbStoCip.Text = Context.Request.UserHostAddress;
                    txttbStoMip.Text = "";


                    //'檔案上傳使用iframe 並如下設定網址
                    txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbStoCde.Text + "&CK=" + txttbStoCon.ClientID + "\"></iframe>";

                }
                break;

            case "ADDSAV": //'新增存檔
                {
                    //'取HTML編輯模組傳回值
                    //'String tbUsrAre = Context.Request.Params["ctl00$ContentPlaceHolder1$txttbUsrAre_A"].ToString();

                    String tbStoCde = txttbStoCde.Text;
                    String tbStoTyp = txttbStoTyp.Text;
                    String tbStoSub = txttbStoSub.Text;
                    String tbStoCon = txttbStoCon.Text;
                    String tbStoPdt = txttbStoPdt.Text;
                    String tbStoTop = txttbStoTop.Text;
                    String tbStoFbs = txttbStoFbs.Text;
                    String tbStoFlg = txttbStoFlg.Text;
                    String tbStoCdt = txttbStoCdt.Text;
                    String tbStoMdt = txttbStoMdt.Text;
                    String tbStoCid = txttbStoCid.Text;
                    String tbStoMid = txttbStoMid.Text;
                    String tbStoCip = txttbStoCip.Text;
                    String tbStoMip = txttbStoMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.InsertCommand = "insert into tbSto("
                    + "tbStoCde"
                    + ",tbStoTyp"
                    + ",tbStoSub"
                    + ",tbStoCon"
                    + ",tbStoPdt"
                    + ",tbStoTop"
                    + ",tbStoFbs"
                    + ",tbStoFlg"
                    + ",tbStoCdt"
                    + ",tbStoMdt"
                    + ",tbStoCid"
                    + ",tbStoMid"
                    + ",tbStoCip"
                    + ",tbStoMip"
                    + ") values("
                    + "@tbStoCde"
                    + ",@tbStoTyp"
                    + ",@tbStoSub"
                    + ",@tbStoCon"
                    + ",@tbStoPdt"
                    + ",@tbStoTop"
                    + ",@tbStoFbs"
                    + ",@tbStoFlg"
                    + ",@tbStoCdt"
                    + ",@tbStoMdt"
                    + ",@tbStoCid"
                    + ",@tbStoMid"
                    + ",@tbStoCip"
                    + ",@tbStoMip"
                    + ")";
                    IzDataSource.InsertParameters.Add("tbStoCde", tbStoCde);
                    IzDataSource.InsertParameters.Add("tbStoTyp", tbStoTyp);
                    IzDataSource.InsertParameters.Add("tbStoSub", tbStoSub);
                    IzDataSource.InsertParameters.Add("tbStoCon", tbStoCon);
                    IzDataSource.InsertParameters.Add("tbStoPdt", tbStoPdt);
                    IzDataSource.InsertParameters.Add("tbStoTop", tbStoTop);
                    IzDataSource.InsertParameters.Add("tbStoFbs", tbStoFbs);
                    IzDataSource.InsertParameters.Add("tbStoFlg", tbStoFlg);
                    IzDataSource.InsertParameters.Add("tbStoCdt", tbStoCdt);
                    IzDataSource.InsertParameters.Add("tbStoMdt", tbStoMdt);
                    IzDataSource.InsertParameters.Add("tbStoCid", tbStoCid);
                    IzDataSource.InsertParameters.Add("tbStoMid", tbStoMid);
                    IzDataSource.InsertParameters.Add("tbStoCip", tbStoCip);
                    IzDataSource.InsertParameters.Add("tbStoMip", tbStoMip);

                    IzDataSource.Insert();
                    IzDataSource.Dispose();
                }
                break;

            case "EDIT": //'修改畫面
                {
                    ltStuTitle.Text = "修改";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbSto where tbStoCde=@tbStoCde";
                    IzDataSource.ParametersAdd("tbStoCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        txttbStoCde.Text = tb.Rows[0]["tbStoCde"].ToString();
                        //txttbStoTyp.Text = tb.Rows[0]["tbStoTyp"].ToString();
                        System.Data.DataTable tbNTP = cfg.getTypLst("NTP");
                        String[] NTPtxt = WebFormBase.GenRdoChkListItemArr(tbNTP, "tbTypSub", true);
                        NTPtxt[0] = "請選擇";
                        String[] NTPval = WebFormBase.GenRdoChkListItemArr(tbNTP, "tbTypTid", true);
                        WebFormBase.GenDropDownListItem(txttbStoTyp, NTPtxt, NTPval, tb.Rows[0]["tbStoTyp"].ToString());
                        tbNTP.Dispose();

                        txttbStoSub.Text = tb.Rows[0]["tbStoSub"].ToString();
                        txttbStoCon.Text = tb.Rows[0]["tbStoCon"].ToString();
                        txttbStoPdt.Text = Convert.ToDateTime(tb.Rows[0]["tbStoPdt"]).ToString("yyyy-MM-dd");
                        txttbStoPdt.Attributes.Add("type", "date");
                        //txttbStoPdt.Attributes["onclick"] = "showCalendar(this, this, 'yyyy/mm/dd','tw',1)";
                        //txttbStoTop.Text = tb.Rows[0]["tbStoTop"].ToString();
                        WebFormBase.GenRdoList(txttbStoTop, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbStoTop"].ToString());
                        //txttbStoFbs.Text = tb.Rows[0]["tbStoFbs"].ToString();
                        WebFormBase.GenRdoList(txttbStoFbs, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbStoFbs"].ToString());
                        //txttbStoFlg.Text = tb.Rows[0]["tbStoFlg"].ToString();
                        WebFormBase.GenRdoList(txttbStoFlg, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbStoFlg"].ToString());
                        txttbStoCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbStoCdt"]).ToString("yyyy/MM/dd HH:mm:ss");
                        txttbStoMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        txttbStoCid.Text = tb.Rows[0]["tbStoCid"].ToString();
                        txttbStoMid.Text = LoginUsr.UsrCde;
                        txttbStoCip.Text = tb.Rows[0]["tbStoCip"].ToString();
                        txttbStoMip.Text = Context.Request.UserHostAddress;

                    }
                    tb.Dispose();

                    //'檔案上傳使用iframe 並如下設定網址
                    txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbStoCde.Text + "&CK=" + txttbStoCon.ClientID + "\"></iframe>";


                }
                break;

            case "EDITSAV": //'修改存檔
                {

                    String tbStoCde = txttbStoCde.Text;
                    String tbStoTyp = txttbStoTyp.Text;
                    String tbStoSub = txttbStoSub.Text;
                    String tbStoCon = txttbStoCon.Text;
                    String tbStoPdt = txttbStoPdt.Text;
                    String tbStoTop = txttbStoTop.Text;
                    String tbStoFbs = txttbStoFbs.Text;
                    String tbStoFlg = txttbStoFlg.Text;
                    String tbStoCdt = txttbStoCdt.Text;
                    String tbStoMdt = txttbStoMdt.Text;
                    String tbStoCid = txttbStoCid.Text;
                    String tbStoMid = txttbStoMid.Text;
                    String tbStoCip = txttbStoCip.Text;
                    String tbStoMip = txttbStoMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.UpdateCommand = "update tbSto set "
                    + "tbStoCde=@tbStoCde"
                    + ",tbStoTyp=@tbStoTyp"
                    + ",tbStoSub=@tbStoSub"
                    + ",tbStoCon=@tbStoCon"
                    + ",tbStoPdt=@tbStoPdt"
                    + ",tbStoTop=@tbStoTop"
                    + ",tbStoFbs=@tbStoFbs"
                    + ",tbStoFlg=@tbStoFlg"
                    + ",tbStoCdt=@tbStoCdt"
                    + ",tbStoMdt=@tbStoMdt"
                    + ",tbStoCid=@tbStoCid"
                    + ",tbStoMid=@tbStoMid"
                    + ",tbStoCip=@tbStoCip"
                    + ",tbStoMip=@tbStoMip"
                    + " where tbStoCde=@tbStoCde";
                    IzDataSource.UpdateParameters.Add("tbStoCde", tbStoCde);
                    IzDataSource.UpdateParameters.Add("tbStoTyp", tbStoTyp);
                    IzDataSource.UpdateParameters.Add("tbStoSub", tbStoSub);
                    IzDataSource.UpdateParameters.Add("tbStoCon", tbStoCon);
                    IzDataSource.UpdateParameters.Add("tbStoPdt", tbStoPdt);
                    IzDataSource.UpdateParameters.Add("tbStoTop", tbStoTop);
                    IzDataSource.UpdateParameters.Add("tbStoFbs", tbStoFbs);
                    IzDataSource.UpdateParameters.Add("tbStoFlg", tbStoFlg);
                    IzDataSource.UpdateParameters.Add("tbStoCdt", tbStoCdt);
                    IzDataSource.UpdateParameters.Add("tbStoMdt", tbStoMdt);
                    IzDataSource.UpdateParameters.Add("tbStoCid", tbStoCid);
                    IzDataSource.UpdateParameters.Add("tbStoMid", tbStoMid);
                    IzDataSource.UpdateParameters.Add("tbStoCip", tbStoCip);
                    IzDataSource.UpdateParameters.Add("tbStoMip", tbStoMip);

                    IzDataSource.Update();
                    IzDataSource.Dispose();
                }
                break;

            case "DELALL": //'多選刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    String SelT = Context.Request.Params["chkSelT"].ToString();
                    String[] SelTArr = SelT.Split(',');
                    for (int i = 0; i < SelTArr.Length; i++)
                    {

                        //'刪除
                        IzDataSource.DeleteCommand = "delete from tbSto where tbStoCde=@tbStoCde";
                        IzDataSource.DeleteParameters.Clear();
                        IzDataSource.DeleteParameters.Add("tbStoCde", SelTArr[i]);
                        IzDataSource.Delete();

                    }

                    IzDataSource.Dispose();
                }
                break;

            case "DELONE": //'單筆刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    //'刪除
                    IzDataSource.DeleteCommand = "delete from tbSto where tbStoCde=@tbStoCde";
                    IzDataSource.DeleteParameters.Clear();
                    IzDataSource.DeleteParameters.Add("tbStoCde", CDE);
                    IzDataSource.Delete();

                    IzDataSource.Dispose();
                }
                break;
            case "VIEW": //'單筆檢視
                {
                    ltStuTitle.Text = "檢視";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbSto where tbStoCde=@tbStoCde";
                    IzDataSource.ParametersAdd("tbStoCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        lbtbStoCde.Text = tb.Rows[0]["tbStoCde"].ToString();
                        lbtbStoTyp.Text = cfg.getTypSub("NTP", tb.Rows[0]["tbStoTyp"].ToString());
                        lbtbStoSub.Text = tb.Rows[0]["tbStoSub"].ToString();
                        lbtbStoCon.Text = tb.Rows[0]["tbStoCon"].ToString();
                        lbtbStoPdt.Text = tb.Rows[0]["tbStoPdt"].ToString();
                        lbtbStoTop.Text = cfg.getFlgNme(tb.Rows[0]["tbStoTop"].ToString());
                        lbtbStoFbs.Text = cfg.getFlgNme(tb.Rows[0]["tbStoFbs"].ToString());
                        lbtbStoFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbStoFlg"].ToString());
                        lbtbStoCdt.Text = tb.Rows[0]["tbStoCdt"].ToString();
                        lbtbStoMdt.Text = tb.Rows[0]["tbStoMdt"].ToString();
                        lbtbStoCid.Text = tb.Rows[0]["tbStoCid"].ToString();
                        lbtbStoMid.Text = tb.Rows[0]["tbStoMid"].ToString();
                        lbtbStoCip.Text = tb.Rows[0]["tbStoCip"].ToString();
                        lbtbStoMip.Text = tb.Rows[0]["tbStoMip"].ToString();

                    }
                    tb.Dispose();
                }
                break;

            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                UPDATE.Visible = false;
                VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;
            case "ADD": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','ADDSAV');";
                //'ADD返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "EDIT": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','EDITSAV');";
                //'EDIT返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "VIEW": //'檢視狀態
                LIST.Visible = false;
                UPDATE.Visible = false;
                VIEW.Visible = true;

                //'VIEW返回按鈕
                lnViewBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbSto where tbStoCde='" + dr["tbStoCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                Label lbXtbStoCde = (Label)e.Item.FindControl("lbXtbStoCde"); //tbStoCde
                Label lbXtbStoTyp = (Label)e.Item.FindControl("lbXtbStoTyp"); //tbStoTyp
                Label lbXtbStoSub = (Label)e.Item.FindControl("lbXtbStoSub"); //tbStoSub
                //Label lbXtbStoCon = (Label)e.Item.FindControl("lbXtbStoCon"); //tbStoCon
                Label lbXtbStoPdt = (Label)e.Item.FindControl("lbXtbStoPdt"); //tbStoPdt
                Label lbXtbStoTop = (Label)e.Item.FindControl("lbXtbStoTop"); //tbStoTop
                Label lbXtbStoClk = (Label)e.Item.FindControl("lbXtbStoClk"); //tbStoClk
                Label lbXtbStoFlg = (Label)e.Item.FindControl("lbXtbStoFlg"); //tbStoFlg
                Label lbXtbStoCdt = (Label)e.Item.FindControl("lbXtbStoCdt"); //tbStoCdt

                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                lbXtbStoCde.Text = tb.Rows[0]["tbStoCde"].ToString();
                lbXtbStoTyp.Text = cfg.getTypSub("NTP", tb.Rows[0]["tbStoTyp"].ToString());
                lbXtbStoSub.Text = tb.Rows[0]["tbStoSub"].ToString();
                //lbXtbStoCon.Text = tb.Rows[0]["tbStoCon"].ToString();
                if (tb.Rows[0]["tbStoPdt"].ToString() == "")
                {
                    lbXtbStoPdt.Text = "";
                }
                else
                {
                    lbXtbStoPdt.Text = Convert.ToDateTime(tb.Rows[0]["tbStoPdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbStoPdt"]).ToString("HH:mm:ss");
                }
                lbXtbStoTop.Text = cfg.getFlgNme(tb.Rows[0]["tbStoTop"].ToString());
                lbXtbStoClk.Text = tb.Rows[0]["tbStoClk"].ToString();
                lbXtbStoFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbStoFlg"].ToString());
                lbXtbStoCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbStoCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbStoCdt"]).ToString("HH:mm:ss");

                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbStoCde"].ToString() + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbStoCde"].ToString() + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbStoCde"].ToString() + "','" + tb.Rows[0]["tbStoSub"].ToString() + "')";

            }
            tb.Dispose();
            IzDataSource.Dispose();
        }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }


}