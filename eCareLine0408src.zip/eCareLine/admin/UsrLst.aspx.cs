﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_UsrLst : System.Web.UI.Page
{

    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"]!=null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] !=null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

           if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbUsrCde from tbUsr where tbUsrCde<>'USR00000000000000001' ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = ""; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;

            case "ADD": //'新增畫面
                {
                    ltStuTitle.Text = "新增";

                    txttbUsrCde.Text = "" + cfg.getcde("USR");
                    txttbUsrNme.Text = "";
                    txttbUsrTyp.Text = "";
                    txttbUsrUid.Text = "";
                    lbtxttbUsrPwd.Text = "<input name=\"txttbUsrPwd\" type=\"password\" size=\"20\" maxlength=\"20\" class=\"form-control\" />";
                    txttbUsrCon.Text = "";
                    txttbUsrEml.Text = "";
                    txttbUsrTel.Text = "";
                    //'txttbUsrStu.Text = "";
                    WebFormBase.GenRdoList(txttbUsrStu, cfg.StuNmeArr, cfg.StuValArr, "0");
                    //'txttbUsrFlg.Text = "";
                    WebFormBase.GenRdoList(txttbUsrFlg, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    txttbUsrCdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbUsrMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    txttbUsrCid.Text = LoginUsr.UsrCde;
                    txttbUsrMid.Text = "";
                    txttbUsrCip.Text = Context.Request.UserHostAddress;
                    txttbUsrMip.Text = "";


                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"

                }
                break;

            case "ADDSAV": //'新增存檔
                {
                    //'取HTML編輯模組傳回值
                    //'String tbUsrAre = Context.Request.Params["ctl00$ContentPlaceHolder1$txttbUsrAre_A"].ToString();

                    String tbUsrCde = txttbUsrCde.Text;
                    String tbUsrNme = txttbUsrNme.Text;
                    String tbUsrTyp = txttbUsrTyp.Text;
                    String tbUsrUid = txttbUsrUid.Text;
                    String tbUsrPwd = Context.Request.Params["txttbUsrPwd"].ToString();
                    String tbUsrCon = txttbUsrCon.Text;
                    String tbUsrEml = txttbUsrEml.Text;
                    String tbUsrTel = txttbUsrTel.Text;
                    String tbUsrStu = txttbUsrStu.Text;
                    String tbUsrFlg = txttbUsrFlg.Text;
                    String tbUsrCdt = txttbUsrCdt.Text;
                    String tbUsrMdt = txttbUsrMdt.Text;
                    String tbUsrCid = txttbUsrCid.Text;
                    String tbUsrMid = txttbUsrMid.Text;
                    String tbUsrCip = txttbUsrCip.Text;
                    String tbUsrMip = txttbUsrMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.InsertCommand = "insert into tbUsr("
                    + "tbUsrCde"
                    + ",tbUsrNme"
                    + ",tbUsrTyp"
                    + ",tbUsrUid"
                    + ",tbUsrPwd"
                    + ",tbUsrCon"
                    + ",tbUsrEml"
                    + ",tbUsrTel"
                    + ",tbUsrStu"
                    + ",tbUsrFlg"
                    + ",tbUsrCdt"
                    + ",tbUsrMdt"
                    + ",tbUsrCid"
                    + ",tbUsrMid"
                    + ",tbUsrCip"
                    + ",tbUsrMip"
                    + ") values("
                    + "@tbUsrCde"
                    + ",@tbUsrNme"
                    + ",@tbUsrTyp"
                    + ",@tbUsrUid"
                    + ",@tbUsrPwd"
                    + ",@tbUsrCon"
                    + ",@tbUsrEml"
                    + ",@tbUsrTel"
                    + ",@tbUsrStu"
                    + ",@tbUsrFlg"
                    + ",@tbUsrCdt"
                    + ",@tbUsrMdt"
                    + ",@tbUsrCid"
                    + ",@tbUsrMid"
                    + ",@tbUsrCip"
                    + ",@tbUsrMip"
                    + ")";
                    IzDataSource.InsertParameters.Add("tbUsrCde", tbUsrCde);
                    IzDataSource.InsertParameters.Add("tbUsrNme", tbUsrNme);
                    IzDataSource.InsertParameters.Add("tbUsrTyp", tbUsrTyp);
                    IzDataSource.InsertParameters.Add("tbUsrUid", tbUsrUid);
                    IzDataSource.InsertParameters.Add("tbUsrPwd", tbUsrPwd);
                    IzDataSource.InsertParameters.Add("tbUsrCon", tbUsrCon);
                    IzDataSource.InsertParameters.Add("tbUsrEml", tbUsrEml);
                    IzDataSource.InsertParameters.Add("tbUsrTel", tbUsrTel);
                    IzDataSource.InsertParameters.Add("tbUsrStu", tbUsrStu);
                    IzDataSource.InsertParameters.Add("tbUsrFlg", tbUsrFlg);
                    IzDataSource.InsertParameters.Add("tbUsrCdt", tbUsrCdt);
                    IzDataSource.InsertParameters.Add("tbUsrMdt", tbUsrMdt);
                    IzDataSource.InsertParameters.Add("tbUsrCid", tbUsrCid);
                    IzDataSource.InsertParameters.Add("tbUsrMid", tbUsrMid);
                    IzDataSource.InsertParameters.Add("tbUsrCip", tbUsrCip);
                    IzDataSource.InsertParameters.Add("tbUsrMip", tbUsrMip);

                    IzDataSource.Insert();
                    IzDataSource.Dispose();
                }
                break;

            case "EDIT": //'修改畫面
                {
                    ltStuTitle.Text = "修改";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbUsr where tbUsrCde=@tbUsrCde";
                    IzDataSource.ParametersAdd("tbUsrCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        txttbUsrCde.Text = tb.Rows[0]["tbUsrCde"].ToString();
                        txttbUsrNme.Text = tb.Rows[0]["tbUsrNme"].ToString();
                        txttbUsrTyp.Text = tb.Rows[0]["tbUsrTyp"].ToString();
                        txttbUsrUid.Text = tb.Rows[0]["tbUsrUid"].ToString();
                        lbtxttbUsrPwd.Text = "<input name=\"txttbUsrPwd\" type=\"password\" size=\"20\" maxlength=\"20\" value=\"" + tb.Rows[0]["tbUsrPwd"].ToString() + "\" class=\"form-control\"/>";
                        txttbUsrCon.Text = tb.Rows[0]["tbUsrCon"].ToString();
                        txttbUsrEml.Text = tb.Rows[0]["tbUsrEml"].ToString();
                        txttbUsrTel.Text = tb.Rows[0]["tbUsrTel"].ToString();
                        //txttbUsrStu.Text = tb.Rows[0]["tbUsrStu"].ToString();
                        WebFormBase.GenRdoList(txttbUsrStu, cfg.StuNmeArr, cfg.StuValArr, tb.Rows[0]["tbUsrStu"].ToString());
                        //txttbUsrFlg.Text = tb.Rows[0]["tbUsrFlg"].ToString();
                        WebFormBase.GenRdoList(txttbUsrFlg, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbUsrFlg"].ToString());
                        txttbUsrCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbUsrCdt"]).ToString("yyyy/MM/dd HH:mm:ss");
                        txttbUsrMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        txttbUsrCid.Text = tb.Rows[0]["tbUsrCid"].ToString();
                        txttbUsrMid.Text = LoginUsr.UsrCde;
                        txttbUsrCip.Text = tb.Rows[0]["tbUsrCip"].ToString();
                        txttbUsrMip.Text = Context.Request.UserHostAddress;

                    }
                    tb.Dispose();

                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"


                }
                break;

            case "EDITSAV": //'修改存檔
                {

                    String tbUsrCde = txttbUsrCde.Text;
                    String tbUsrNme = txttbUsrNme.Text;
                    String tbUsrTyp = txttbUsrTyp.Text;
                    String tbUsrUid = txttbUsrUid.Text;
                    String tbUsrPwd = Context.Request.Params["txttbUsrPwd"].ToString();
                    String tbUsrCon = txttbUsrCon.Text;
                    String tbUsrEml = txttbUsrEml.Text;
                    String tbUsrTel = txttbUsrTel.Text;
                    String tbUsrStu = txttbUsrStu.Text;
                    String tbUsrFlg = txttbUsrFlg.Text;
                    String tbUsrCdt = txttbUsrCdt.Text;
                    String tbUsrMdt = txttbUsrMdt.Text;
                    String tbUsrCid = txttbUsrCid.Text;
                    String tbUsrMid = txttbUsrMid.Text;
                    String tbUsrCip = txttbUsrCip.Text;
                    String tbUsrMip = txttbUsrMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.UpdateCommand = "update tbUsr set "
                    + "tbUsrCde=@tbUsrCde"
                    + ",tbUsrNme=@tbUsrNme"
                    + ",tbUsrTyp=@tbUsrTyp"
                    + ",tbUsrUid=@tbUsrUid"
                    + ",tbUsrPwd=@tbUsrPwd"
                    + ",tbUsrCon=@tbUsrCon"
                    + ",tbUsrEml=@tbUsrEml"
                    + ",tbUsrTel=@tbUsrTel"
                    + ",tbUsrStu=@tbUsrStu"
                    + ",tbUsrFlg=@tbUsrFlg"
                    + ",tbUsrCdt=@tbUsrCdt"
                    + ",tbUsrMdt=@tbUsrMdt"
                    + ",tbUsrCid=@tbUsrCid"
                    + ",tbUsrMid=@tbUsrMid"
                    + ",tbUsrCip=@tbUsrCip"
                    + ",tbUsrMip=@tbUsrMip"
                    + " where tbUsrCde=@tbUsrCde";
                    IzDataSource.UpdateParameters.Add("tbUsrCde", tbUsrCde);
                    IzDataSource.UpdateParameters.Add("tbUsrNme", tbUsrNme);
                    IzDataSource.UpdateParameters.Add("tbUsrTyp", tbUsrTyp);
                    IzDataSource.UpdateParameters.Add("tbUsrUid", tbUsrUid);
                    IzDataSource.UpdateParameters.Add("tbUsrPwd", tbUsrPwd);
                    IzDataSource.UpdateParameters.Add("tbUsrCon", tbUsrCon);
                    IzDataSource.UpdateParameters.Add("tbUsrEml", tbUsrEml);
                    IzDataSource.UpdateParameters.Add("tbUsrTel", tbUsrTel);
                    IzDataSource.UpdateParameters.Add("tbUsrStu", tbUsrStu);
                    IzDataSource.UpdateParameters.Add("tbUsrFlg", tbUsrFlg);
                    IzDataSource.UpdateParameters.Add("tbUsrCdt", tbUsrCdt);
                    IzDataSource.UpdateParameters.Add("tbUsrMdt", tbUsrMdt);
                    IzDataSource.UpdateParameters.Add("tbUsrCid", tbUsrCid);
                    IzDataSource.UpdateParameters.Add("tbUsrMid", tbUsrMid);
                    IzDataSource.UpdateParameters.Add("tbUsrCip", tbUsrCip);
                    IzDataSource.UpdateParameters.Add("tbUsrMip", tbUsrMip);

                    IzDataSource.Update();
                    IzDataSource.Dispose();
                }
                break;

            case "DELALL": //'多選刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    String SelT = Context.Request.Params["chkSelT"].ToString();
                    String[] SelTArr = SelT.Split(',');
                    for (int i = 0; i < SelTArr.Length; i++)
                    {

                        //'刪除
                        IzDataSource.DeleteCommand = "delete from tbUsr where tbUsrCde=@tbUsrCde";
                        IzDataSource.DeleteParameters.Clear();
                        IzDataSource.DeleteParameters.Add("tbUsrCde", SelTArr[i]);
                        IzDataSource.Delete();

                    }

                    IzDataSource.Dispose();
                }
                break;

            case "DELONE": //'單筆刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    //'刪除
                    IzDataSource.DeleteCommand = "delete from tbUsr where tbUsrCde=@tbUsrCde";
                    IzDataSource.DeleteParameters.Clear();
                    IzDataSource.DeleteParameters.Add("tbUsrCde", CDE);
                    IzDataSource.Delete();

                    IzDataSource.Dispose();
                }
                break;
            case "VIEW": //'單筆檢視
                {
                    ltStuTitle.Text = "檢視";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbUsr where tbUsrCde=@tbUsrCde";
                    IzDataSource.ParametersAdd("tbUsrCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        lbtbUsrCde.Text = tb.Rows[0]["tbUsrCde"].ToString();
                        lbtbUsrNme.Text = tb.Rows[0]["tbUsrNme"].ToString();
                        lbtbUsrTyp.Text = tb.Rows[0]["tbUsrTyp"].ToString();
                        lbtbUsrUid.Text = tb.Rows[0]["tbUsrUid"].ToString();
                        lbtbUsrPwd.Text = tb.Rows[0]["tbUsrPwd"].ToString();
                        lbtbUsrCon.Text = tb.Rows[0]["tbUsrCon"].ToString();
                        lbtbUsrEml.Text = tb.Rows[0]["tbUsrEml"].ToString();
                        lbtbUsrTel.Text = tb.Rows[0]["tbUsrTel"].ToString();
                        lbtbUsrStu.Text = cfg.getStuNme(tb.Rows[0]["tbUsrStu"].ToString());
                        lbtbUsrFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbUsrFlg"].ToString());
                        lbtbUsrCdt.Text = tb.Rows[0]["tbUsrCdt"].ToString();
                        lbtbUsrMdt.Text = tb.Rows[0]["tbUsrMdt"].ToString();
                        lbtbUsrCid.Text = tb.Rows[0]["tbUsrCid"].ToString();
                        lbtbUsrMid.Text = tb.Rows[0]["tbUsrMid"].ToString();
                        lbtbUsrCip.Text = tb.Rows[0]["tbUsrCip"].ToString();
                        lbtbUsrMip.Text = tb.Rows[0]["tbUsrMip"].ToString();

                    }
                    tb.Dispose();
                }
                break;

            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                UPDATE.Visible = false;
                VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;
            case "ADD": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','ADDSAV');";
                //'ADD返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "EDIT": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','EDITSAV');";
                //'EDIT返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "VIEW": //'檢視狀態
                LIST.Visible = false;
                UPDATE.Visible = false;
                VIEW.Visible = true;

                //'VIEW返回按鈕
                lnViewBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
          if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem){

             System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbUsr where tbUsrCde='" + dr["tbUsrCde"].ToString() + "'");
            if (tb.Rows.Count > 0 ){

                Label lbXtbUsrCde = (Label)e.Item.FindControl("lbXtbUsrCde"); //'tbUsrCde
                Label lbXtbUsrNme = (Label)e.Item.FindControl("lbXtbUsrNme"); //'tbUsrNme
                //'Label lbXtbUsrTyp = (Label)e.Item.FindControl("lbXtbUsrTyp"); //'tbUsrTyp
                Label lbXtbUsrUid = (Label)e.Item.FindControl("lbXtbUsrUid"); //'tbUsrUid
                //'Label lbXtbUsrPwd = (Label)e.Item.FindControl("lbXtbUsrPwd"); //'tbUsrPwd
                //'Label lbXtbUsrCon = (Label)e.Item.FindControl("lbXtbUsrCon"); //'tbUsrCon
                //'Label lbXtbUsrEml = (Label)e.Item.FindControl("lbXtbUsrEml"); //'tbUsrEml
                Label lbXtbUsrTel = (Label)e.Item.FindControl("lbXtbUsrTel"); //'tbUsrTel
               Label lbXtbUsrStu = (Label)e.Item.FindControl("lbXtbUsrStu"); //'tbUsrStu
                Label lbXtbUsrFlg = (Label)e.Item.FindControl("lbXtbUsrFlg"); //'tbUsrFlg
                Label lbXtbUsrCdt = (Label)e.Item.FindControl("lbXtbUsrCdt"); //'tbUsrCdt

                HyperLink lnSETUP =(HyperLink)e.Item.FindControl("lnSETUP"); //'設定
                HyperLink lnVIEW =(HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT =(HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL =(HyperLink)e.Item.FindControl("lnDEL"); //'刪除


                lbXtbUsrCde.Text = tb.Rows[0]["tbUsrCde"].ToString();
                lbXtbUsrNme.Text = tb.Rows[0]["tbUsrNme"].ToString();
                //lbXtbUsrTyp.Text = tb.Rows[0]["tbUsrTyp"].ToString();
                lbXtbUsrUid.Text = tb.Rows[0]["tbUsrUid"].ToString();
                //lbXtbUsrPwd.Text = tb.Rows[0]["tbUsrPwd"].ToString();
                //lbXtbUsrCon.Text = tb.Rows[0]["tbUsrCon"].ToString();
                //lbXtbUsrEml.Text = tb.Rows[0]["tbUsrEml"].ToString();
                
                lbXtbUsrTel.Text = tb.Rows[0]["tbUsrTel"].ToString();
                lbXtbUsrStu.Text = cfg.getStuNme(tb.Rows[0]["tbUsrStu"].ToString());
                lbXtbUsrFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbUsrFlg"].ToString());
                lbXtbUsrCdt.Text = Convert.ToDateTime ( tb.Rows[0]["tbUsrCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime ( tb.Rows[0]["tbUsrCdt"]).ToString("HH:mm:ss");

                lnSETUP.NavigateUrl = "javascript:goPage('UsrGrpSet.aspx?f=" + Context.Request.QueryString["f"].ToString() + "&CDE=" + tb.Rows[0]["tbUsrCde"].ToString() + "')";
                lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbUsrCde"] + "')";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbUsrCde"] + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbUsrCde"] + "','" + tb.Rows[0]["tbUsrNme"].ToString() + "')";

            }
            tb.Dispose();
            IzDataSource.Dispose();
          }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }

}