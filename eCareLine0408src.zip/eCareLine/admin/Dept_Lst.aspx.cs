﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_Dept_Lst : System.Web.UI.Page
{
    SqlConnection cnn;
    // string myConnectString = @"Server='localhost\SQLEXPRESS'; database='MyDB1';Integrated Security=True;";
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    cfg cfg = new cfg();
    LoginUsr LoginUsr;
    protected void Page_Load(object sender, EventArgs e)
    {
        btnQry_Click(null, EventArgs.Empty);
    }

    protected void btnQry_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            SqlDataReader myDR;
            string tbName = "tbDept";  // a View or Table Name
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.CommandText = "SELECT COUNT(*) FROM " + tbName + " ";
            myDR = cmd.ExecuteReader();
            string rowTotal="0";
            if (myDR.Read()) rowTotal = myDR[0].ToString();
            myDR.Close();
            
            int num = int.Parse(txtNum.Text);
            cmd.Parameters.AddWithValue("@code", "%" + txtData.Text.Trim() + "%");
            cmd.CommandText = "SELECT TOP " + num + " * FROM " + tbName + " ";
            cmd.CommandText += "WHERE dept_ID LIKE @code  OR ";
            cmd.CommandText += "dept_Name LIKE @code OR ";
            cmd.CommandText += "dep_Notes LIKE @code";
            
            myDR = cmd.ExecuteReader();
            // Response.Write("<p>開啟資料庫的資料表: " + tbName + " 正常!</p>");

            String urlShow, urlDel, urlUpt;
            string css1 = @"table table-striped table - bordered table - hover";
            lbResult.Text = "<table class="+ css1 +"><tr>";
            // 顯示欄位名稱
            for (int i = 0; i < myDR.FieldCount; i++)
            {
                lbResult.Text += "<td>";
                lbResult.Text += myDR.GetName(i).ToString();
                lbResult.Text += "</td>";
            }
            lbResult.Text += "<td nowrap >顯示</td>";
            lbResult.Text += "<td nowrap >更新</td>";
            lbResult.Text += "<td nowrap>刪除</td>";
            lbResult.Text += "</tr>";
            int qryCount = 0;
            while (myDR.Read())
            {
                qryCount++;
                lbResult.Text += "<tr>";
                for (int i = 0; i < myDR.FieldCount; i++)
                {
                    //判斷圖片檔案欄位
                    if (myDR.GetName(i).ToString() == "照片")
                    {
                        lbResult.Text += "<td>";
                        lbResult.Text += "<img src=" + myDR[i].ToString() + " width=60>";
                        lbResult.Text += "</td>";
                    }
                    else
                    {
                        lbResult.Text += "<td>" + myDR[i].ToString() + "</td>";
                    }
                }
                // 傳遞顯示ID
                urlShow = "dept_Show.aspx?staID=" + myDR["dept_ID"].ToString();
                lbResult.Text += "<td>";
                lbResult.Text += "<a href=" + urlShow + ">顯示</a>";
                lbResult.Text += "</td>";
                // 傳遞修改ID
                urlUpt = "dept_Upt.aspx?staID=" + myDR["dept_ID"].ToString();
                lbResult.Text += "<td>";
                lbResult.Text += "<a href=" + urlUpt + ">更新</a>";
                lbResult.Text += "</td>";
                // 傳遞刪除ID
                urlDel = "dept_Del.aspx?staID=" + myDR["dept_ID"].ToString();
                lbResult.Text += "<td>";
                lbResult.Text += "<a href=" + urlDel + ">刪除</a>";
                lbResult.Text += "</td>";

                lbResult.Text += "</tr>";
            }
            lbResult.Text += "</table>";
            // 顯示資料數
            lbResult.Text += "<br />符合查詢條件資料數: " + qryCount + " / " + rowTotal;
            cnn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("dept_Add.aspx");
    }
}