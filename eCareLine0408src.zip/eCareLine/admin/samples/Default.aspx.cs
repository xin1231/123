﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_samples_Default : System.Web.UI.Page
{
    cfg cfg = new cfg();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        lbResult.Text = cfg.getcde("TST");
    }
}