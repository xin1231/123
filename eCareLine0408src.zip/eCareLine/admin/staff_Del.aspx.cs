﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.IO;

public partial class admin_staff_Del : System.Web.UI.Page
{
    cfg cfg = new cfg();
    LoginUsr LoginUsr;
    string staID;
    SqlConnection cnn;
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    string photoFileName = "";
    protected void Page_Load(object sender, EventArgs e)
    {
            staID = Context.Request.QueryString["staID"];
            DisplayRecord(staID);
            btnDelOK.Text = "確定要刪除:[" + staID + "]這筆資料?";
    }
    protected void DisplayRecord(string ID)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "vwStaffs";

            SqlCommand cmd = new SqlCommand("", cnn);

            cmd.Parameters.AddWithValue("@code", ID);
            cmd.CommandText = "SELECT * FROM " + tbName + " ";
            cmd.CommandText += "WHERE staff_ID = @code";
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();
            // Response.Write("<p>開啟資料庫的資料表: " + tbName + " 正常!</p>");

            // 顯示資料
            lbResult.Text = "<table border=1>";
            if (myDR.Read())
            {
                lbResult.Text = "<tr>";
                for (int i = 0; i < myDR.FieldCount; i++)
                {
                    //判斷圖片檔案欄位
                    if (myDR.GetName(i).ToString() == "照片")
                    {
                        lbResult.Text += "<td>";
                        lbResult.Text += "<img src=" + myDR[i].ToString() + " width=100>";
                        lbResult.Text += "</td>";
                        photoFileName = myDR[i].ToString();
                    }
                    else
                    {
                        lbResult.Text += "<td>" + myDR[i].ToString() + "</td>";
                    }
                }
                lbResult.Text += "</tr>";
            }
            else
            {
                lbResult.Text += " 查無此資料...";
            }
            lbResult.Text += "</table>";
            cnn.Close();
        }
        catch (Exception ex)
        {
            //  Response.Write(ex.Message);
            lbResult.Text = ex.Message + " or 查無此資料...";
        }

    }

    protected void btnDelOK_Click(object sender, EventArgs e)
    {
        try
        {
            if (staID.Length > 1)
            {
                cnn = new SqlConnection(myConnectString);
                cnn.Open();
                SqlCommand cmd = new SqlCommand("", cnn);
                cmd.CommandText = "DELETE FROM tbStaff WHERE ";
                cmd.CommandText += "staff_ID = @code";
                cmd.Parameters.AddWithValue("@code", staID);
                cmd.ExecuteNonQuery();
                cnn.Close();

                DelPhotoFile(photoFileName);
                // Response.Write("<p>刪除成功!</p>");

                btnDelOK.Text = "完成刪除:[" + staID + "]這筆資料!";
                staID = "";
            }
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
    protected void DelPhotoFile(string filename)
    {
        try {
            // 圖片檔案路徑, 還要再優化
            // filename = Server.MapPath("/") + "admin/" + filename;
            filename = Server.MapPath("/") + cfg.getAppSetting("AdminDefPath") + filename;

            File.Delete(filename);
        }
        catch (Exception ex)
        {
             Response.Write("DelPhotoFile Problem: " + ex.Message);
        }

    }
}