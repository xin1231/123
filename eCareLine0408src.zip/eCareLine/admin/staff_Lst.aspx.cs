﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;

public partial class admin_vwUsers : System.Web.UI.Page
{
    SqlConnection cnn;
    // string myConnectString = @"Server='localhost\SQLEXPRESS'; database='MyDB1';Integrated Security=True;";
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
    cfg cfg = new cfg();
    LoginUsr LoginUsr;
    protected void Page_Load(object sender, EventArgs e)
    {
        // 顯示查詢結果
        btnQry_Click(null, EventArgs.Empty);
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Response.Redirect("staff_Add.aspx");
    }

    protected void btnQry_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "vwStaffs";  // a View Name

            SqlCommand cmd = new SqlCommand("", cnn);
            int num = int.Parse(txtNum.Text);
            cmd.CommandText = "SELECT TOP " + num + " * FROM " + tbName + " ";
            cmd.Parameters.AddWithValue("@code", "%" + txtData.Text.Trim() + "%");
            cmd.CommandText += "WHERE [姓名] LIKE @code  OR ";
            cmd.CommandText += "[電話] LIKE @code OR ";
            cmd.CommandText += "[staff_ID] LIKE @code";
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();
            // Response.Write("<p>開啟資料庫的資料表: " + tbName + " 正常!</p>");

            String urlDel, urlUpt;
            string css1 = @"table table-striped table - bordered table - hover";
            lbResult.Text = "<table class=" + css1 + "><tr>";
            // 顯示欄位名稱
            for (int i = 0; i < myDR.FieldCount; i++)
            {
                lbResult.Text += "<td>";
                lbResult.Text += myDR.GetName(i).ToString();
                lbResult.Text += "</td>";
            }
            lbResult.Text += "<td nowrap >更新</td>";
            lbResult.Text += "<td>刪除</td>";
            lbResult.Text += "</tr>";
            while (myDR.Read())
            {
                lbResult.Text += "<tr>";
                for (int i = 0; i < myDR.FieldCount; i++)
                {
                    //判斷圖片檔案欄位
                    if (myDR.GetName(i).ToString() == "照片")
                    {
                        lbResult.Text += "<td>";
                        lbResult.Text += "<img src=" + myDR[i].ToString() + " width=60>";
                        lbResult.Text += "</td>";
                    }
                    else
                    {
                        lbResult.Text += "<td>" + myDR[i].ToString() + "</td>";
                    }
                }
                // 傳遞修改ID
                urlUpt = "staff_Upt.aspx?staID=" + myDR["staff_ID"].ToString();
                lbResult.Text += "<td>";
                lbResult.Text += "<a href=" + urlUpt + ">更新</a>";
                lbResult.Text += "</td>";
                // 傳遞刪除ID
                urlDel = "staff_Del.aspx?staID=" + myDR["staff_ID"].ToString();
                lbResult.Text += "<td>";
                lbResult.Text += "<a href=" + urlDel + ">刪除</a>";
                lbResult.Text += "</td>";

                lbResult.Text += "</tr>";
            }
            lbResult.Text += "</table>";

            cnn.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
}