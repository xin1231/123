﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_UsrGrpSet : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10000;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    String UsrCde = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        UsrCde = DataAccess.ClsSqlChr(Context.Request.QueryString["CDE"].ToString());

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbGrpCde from tbGrp where 1=1 ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = ""; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;



            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                //UPDATE.Visible = false;
                //VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                lnSelDel.Visible = false;
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                lnADD.Visible = false;
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;

            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbGrp where tbGrpCde='" + dr["tbGrpCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                Label lbXtbGrpCde = (Label)e.Item.FindControl("lbXtbGrpCde"); //tbGrpCde
                Label lbXtbGrpSub = (Label)e.Item.FindControl("lbXtbGrpSub"); //tbGrpSub
                //Label lbXtbGrpCon = (Label)e.Item.FindControl("lbXtbGrpCon"); //tbGrpCon
                //Label lbXtbGrpNot = (Label)e.Item.FindControl("lbXtbGrpNot"); //tbGrpNot
                Label lbXtbGrpFlg = (Label)e.Item.FindControl("lbXtbGrpFlg"); //tbGrpFlg
                Label lbXtbGrpCdt = (Label)e.Item.FindControl("lbXtbGrpCdt"); //tbGrpCdt

                //HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                //HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                //HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除

                Label lbCheck = (Label)e.Item.FindControl("lbCheck");

                lbXtbGrpCde.Text = tb.Rows[0]["tbGrpCde"].ToString();
                lbXtbGrpSub.Text = tb.Rows[0]["tbGrpSub"].ToString();
                //lbXtbGrpCon.Text = tb.Rows[0]["tbGrpCon"].ToString();
                //lbXtbGrpNot.Text = tb.Rows[0]["tbGrpNot"].ToString();
                lbXtbGrpFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbGrpFlg"].ToString());
                lbXtbGrpCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbGrpCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbGrpCdt"]).ToString("HH:mm:ss");

                //lnVIEW.NavigateUrl = "javascript:goView('List1','" + tb.Rows[0]["tbGrpCde"].ToString() + "')";
                //lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbGrpCde"].ToString() + "')";
                //lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbGrpCde"].ToString() + "','" + tb.Rows[0]["tbGrpSub"].ToString() + "')";


                Boolean CheckTT = false;
                System.Data.DataTable rlUsrGrp = mnuDA.UsrGrpSelectOne(UsrCde, tb.Rows[0]["tbGrpCde"].ToString());
                if (rlUsrGrp.Rows.Count > 0){
                    CheckTT = true;
                }
                rlUsrGrp.Dispose();

                if (CheckTT ==true){
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbGrpCde"].ToString() + "\" checked/>";
                }
                else{
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbGrpCde"].ToString() + "\" />";
                }

            }
            tb.Dispose();
            IzDataSource.Dispose();
        }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }


    protected void bntSave_Click(object sender, EventArgs e)
    {
        IzDataSource IzDataSource = new IzDataSource();
        IzDataSource.ExecuteSQLNoneQuery("delete from rlUsrGrp where tbUsrCde='" + UsrCde + "'");

        if (Context.Request.Params["chkSelT"] != null)
        {
            String[] CdeArr = Context.Request.Params["chkSelT"].ToString().Split(',');
            for (int i = 0; i < CdeArr.Length; i++)
            {
                String CdeT = CdeArr[i].Trim();
                if (CdeT != "")
                {
                    String SqlStr = "insert into rlUsrGrp(tbUsrCde,tbGrpCde) values('" + UsrCde + "','" + CdeT + "')";
                    IzDataSource.ExecuteSQLNoneQuery(SqlStr);
                }
            }
        }
        WebFormBase.ShowJavaScriptMsgBack(Response, "存檔完畢", "UsrLst.aspx?f=" + Context.Request.QueryString["f"].ToString());

    }
    protected void bntBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("UsrLst.aspx?f=" + Context.Request.QueryString["f"].ToString());
    }
}