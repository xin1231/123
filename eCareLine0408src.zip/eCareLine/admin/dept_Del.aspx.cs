﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Web.Configuration;
public partial class admin_dept_Del : System.Web.UI.Page
{
    string staID;
    SqlConnection cnn;
    string myConnectString = WebConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        staID = Context.Request.QueryString["staID"];
        DisplayRecord(staID);
        btnDelOK.Text = "確定要刪除:[" + staID + "]這筆資料?";
    }

    protected void DisplayRecord(string ID)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            string tbName = "tbDept";

            SqlCommand cmd = new SqlCommand("", cnn);

            cmd.Parameters.AddWithValue("@code", ID);
            cmd.CommandText = "SELECT * FROM " + tbName + " ";
            cmd.CommandText += "WHERE dept_ID = @code";
            SqlDataReader myDR;
            myDR = cmd.ExecuteReader();
            // Response.Write("<p>開啟資料庫的資料表: " + tbName + " 正常!</p>");

            lbResult.Text = "<table border=1><tr>";
            if (myDR.Read())
            {
                for (int i = 0; i < myDR.FieldCount; i++)
                {
                    //判斷圖片檔案欄位
                    if (myDR.GetName(i).ToString() == "照片")
                    {
                        lbResult.Text += "<td>";
                        lbResult.Text += "<img src=" + myDR[i].ToString() + " width=100>";
                        lbResult.Text += "</td>";
                    }
                    else
                    {
                        lbResult.Text += "<td>" + myDR[i].ToString() + "</td>";
                    }
                }
                lbResult.Text += "</tr>";
            }
            else
            {
                lbResult.Text = "查無此資料...";
            }
            lbResult.Text += "</table>";
            cnn.Close();
        }
        catch (Exception ex)
        {
            //  Response.Write(ex.Message);
            lbResult.Text = "查無此資料..." + ex.Message;
        }

    }

    protected void btnDelOK_Click(object sender, EventArgs e)
    {
        try
        {
            cnn = new SqlConnection(myConnectString);
            cnn.Open();
            SqlCommand cmd = new SqlCommand("", cnn);
            cmd.CommandText = "DELETE FROM tbDept WHERE ";
            cmd.CommandText += "dept_ID = @code";
            cmd.Parameters.AddWithValue("@code", staID);
            cmd.ExecuteNonQuery();
            cnn.Close();
            // Response.Write("<p>刪除成功!</p>");
            btnDelOK.Text = "完成刪除:[" + staID + "]這筆資料!";
        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }

    }
}