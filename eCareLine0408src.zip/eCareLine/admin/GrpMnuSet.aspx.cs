﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_GrpMnuSet : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();


    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10000;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    String POW = "";

    String TOPCDE = "";

    String GrpCde = "";

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }

        GrpCde = DataAccess.ClsSqlChr(Context.Request.QueryString["CDE"].ToString());

        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_TOPCDE"] != null) TOPCDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_TOPCDE"].ToString()); //'目前資料上層編號


        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbMnuCde from tbMnu where (tbMnuTopCde is null or tbMnuTopCde='') ";

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = "tbMnuSrt"; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;



            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                //UPDATE.Visible = false;
                //VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                lnSelDel.Visible = false;
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                lnADD.Visible = false;
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;

            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                Label lbBOW = (Label)e.Item.FindControl("lbBOW"); //'新增次層
                Label lbADD = (Label)e.Item.FindControl("lbADD"); //'檢視
                Label lbEDIT = (Label)e.Item.FindControl("lbEDIT"); //'修改
                Label lbDEL = (Label)e.Item.FindControl("lbDEL"); //'刪除

                Label lbCheck = (Label)e.Item.FindControl("lbCheck");

                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "<i class=\"fa fa-sun-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text = mnuDA.getMnuTypNme(tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");

       

                String PowT = "";
                System.Data.DataTable rlGrpMnu = mnuDA.GrpMnuSelectOne(GrpCde, tb.Rows[0]["tbMnuCde"].ToString());
                if (rlGrpMnu.Rows.Count > 0)
                {
                    PowT = rlGrpMnu.Rows[0]["tbMnuPow"].ToString();
                }
                rlGrpMnu.Dispose();

                if (PowT == "")
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" />";
                }
                else
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" checked/>";
                }

                String BodyStr = "";

                BodyStr = BodyStr + "  <select name=\"BOW" + tb.Rows[0]["tbMnuCde"].ToString() + "\">" + "\r\n";
                if (PowT.IndexOf("BOW01") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\">全部</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\" selected>全部</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW02") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\">單位</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\" selected>單位</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW03") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\">個人</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\" selected>個人</option>" + "\r\n";
                }
                BodyStr = BodyStr + "  </select>" + "\r\n";
                lbBOW.Text = "" + BodyStr;
                if (PowT.IndexOf("ADD") < 0)
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" />";
                }
                else
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" checked/>";
                }
                if (PowT.IndexOf("EDIT") < 0)
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" />";
                }
                else
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" checked/>";
                }
                if (PowT.IndexOf("DEL") < 0)
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" />";
                }
                else
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" checked/>";
                }


            }
            tb.Dispose();


            Repeater Repeater2 = (Repeater)e.Item.FindControl("Repeater2");
            System.Data.DataTable tb2 = IzDataSource.GenDataTable("select tbMnuCde from tbMnu where tbMnuTopCde='" + dr["tbMnuCde"].ToString() + "' order by tbMnuSrt");
            Repeater2.DataSource = tb2;
            Repeater2.DataBind();

            IzDataSource.Dispose();

        }
    }

    protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                Label lbBOW = (Label)e.Item.FindControl("lbBOW"); //'新增次層
                Label lbADD = (Label)e.Item.FindControl("lbADD"); //'檢視
                Label lbEDIT = (Label)e.Item.FindControl("lbEDIT"); //'修改
                Label lbDEL = (Label)e.Item.FindControl("lbDEL"); //'刪除

                Label lbCheck = (Label)e.Item.FindControl("lbCheck");

                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "　　<i class=\"fa fa-moon-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text = mnuDA.getMnuTypNme(tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");



                String PowT = "";
                System.Data.DataTable rlGrpMnu = mnuDA.GrpMnuSelectOne(GrpCde, tb.Rows[0]["tbMnuCde"].ToString());
                if (rlGrpMnu.Rows.Count > 0)
                {
                    PowT = rlGrpMnu.Rows[0]["tbMnuPow"].ToString();
                }
                rlGrpMnu.Dispose();

                if (PowT == "")
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" />";
                }
                else
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" checked/>";
                }

                String BodyStr = "";

                BodyStr = BodyStr + "  <select name=\"BOW" + tb.Rows[0]["tbMnuCde"].ToString() + "\">" + "\r\n";
                if (PowT.IndexOf("BOW01") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\">全部</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\" selected>全部</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW02") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\">單位</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\" selected>單位</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW03") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\">個人</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\" selected>個人</option>" + "\r\n";
                }
                BodyStr = BodyStr + "  </select>" + "\r\n";
                lbBOW.Text = "" + BodyStr;
                if (PowT.IndexOf("ADD") < 0)
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" />";
                }
                else
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" checked/>";
                }
                if (PowT.IndexOf("EDIT") < 0)
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" />";
                }
                else
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" checked/>";
                }
                if (PowT.IndexOf("DEL") < 0)
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" />";
                }
                else
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" checked/>";
                }

            }
            tb.Dispose();


            Repeater Repeater3 = (Repeater)e.Item.FindControl("Repeater3");
            System.Data.DataTable tb3 = IzDataSource.GenDataTable("select tbMnuCde from tbMnu where tbMnuTopCde='" + dr["tbMnuCde"].ToString() + "' order by tbMnuSrt");
            Repeater3.DataSource = tb3;
            Repeater3.DataBind();

            IzDataSource.Dispose();

        }
    }


    protected void Repeater3_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbMnu where tbMnuCde='" + dr["tbMnuCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                //Label lbXtbMnuCde = (Label)e.Item.FindControl("lbXtbMnuCde"); //tbMnuCde
                //Label lbXtbMnuTopCde = (Label)e.Item.FindControl("lbXtbMnuTopCde"); //tbMnuTopCde
                Label lbXtbMnuSub = (Label)e.Item.FindControl("lbXtbMnuSub"); //tbMnuSub
                //Label lbXtbMnuCon = (Label)e.Item.FindControl("lbXtbMnuCon"); //tbMnuCon
                Label lbXtbMnuTyp = (Label)e.Item.FindControl("lbXtbMnuTyp"); //tbMnuTyp
                //Label lbXtbMnuUrl = (Label)e.Item.FindControl("lbXtbMnuUrl"); //tbMnuUrl
                Label lbXtbMnuSrt = (Label)e.Item.FindControl("lbXtbMnuSrt"); //tbMnuSrt
                Label lbXtbMnuFlg = (Label)e.Item.FindControl("lbXtbMnuFlg"); //tbMnuFlg
                Label lbXtbMnuCdt = (Label)e.Item.FindControl("lbXtbMnuCdt"); //tbMnuCdt

                Label lbBOW = (Label)e.Item.FindControl("lbBOW"); //'新增次層
                Label lbADD = (Label)e.Item.FindControl("lbADD"); //'檢視
                Label lbEDIT = (Label)e.Item.FindControl("lbEDIT"); //'修改
                Label lbDEL = (Label)e.Item.FindControl("lbDEL"); //'刪除

                Label lbCheck = (Label)e.Item.FindControl("lbCheck");

                //lbXtbMnuCde.Text = tb.Rows[0]["tbMnuCde"].ToString();
                //lbXtbMnuTopCde.Text = tb.Rows[0]["tbMnuTopCde"].ToString();
                lbXtbMnuSub.Text = "　　　　<i class=\"fa fa-star-o\">　</i>" + tb.Rows[0]["tbMnuSub"].ToString();
                //lbXtbMnuCon.Text = tb.Rows[0]["tbMnuCon"].ToString();
                lbXtbMnuTyp.Text = mnuDA.getMnuTypNme(tb.Rows[0]["tbMnuTyp"].ToString());
                //lbXtbMnuUrl.Text = tb.Rows[0]["tbMnuUrl"].ToString();
                lbXtbMnuSrt.Text = tb.Rows[0]["tbMnuSrt"].ToString();
                lbXtbMnuFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbMnuFlg"].ToString());
                lbXtbMnuCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbMnuCdt"]).ToString("HH:mm:ss");

                String PowT = "";
                System.Data.DataTable rlGrpMnu = mnuDA.GrpMnuSelectOne(GrpCde, tb.Rows[0]["tbMnuCde"].ToString());
                if (rlGrpMnu.Rows.Count > 0)
                {
                    PowT = rlGrpMnu.Rows[0]["tbMnuPow"].ToString();
                }
                rlGrpMnu.Dispose();

                if (PowT == "")
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" />";
                }
                else
                {
                    lbCheck.Text = "<input type=\"checkbox\" name=\"chkSelT\" value=\"" + tb.Rows[0]["tbMnuCde"].ToString() + "\" onclick=\"setcheck(this,'" + tb.Rows[0]["tbMnuCde"].ToString() + "')\" checked/>";
                }

                String BodyStr = "";

                BodyStr = BodyStr + "  <select name=\"BOW" + tb.Rows[0]["tbMnuCde"].ToString() + "\">" + "\r\n";
                if (PowT.IndexOf("BOW01") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\">全部</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW01\" selected>全部</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW02") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\">單位</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW02\" selected>單位</option>" + "\r\n";
                }
                if (PowT.IndexOf("BOW03") < 0)
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\">個人</option>" + "\r\n";
                }
                else
                {
                    BodyStr = BodyStr + "    <option value=\"BOW03\" selected>個人</option>" + "\r\n";
                }
                BodyStr = BodyStr + "  </select>" + "\r\n";
                lbBOW.Text = "" + BodyStr;
                if (PowT.IndexOf("ADD") < 0)
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" />";
                }
                else
                {
                    lbADD.Text = "<input type=\"checkbox\" name=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkADD" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"ADD\" checked/>";
                }
                if (PowT.IndexOf("EDIT") < 0)
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" />";
                }
                else
                {
                    lbEDIT.Text = "<input type=\"checkbox\" name=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkEDIT" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"EDIT\" checked/>";
                }
                if (PowT.IndexOf("DEL") < 0)
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" />";
                }
                else
                {
                    lbDEL.Text = "<input type=\"checkbox\" name=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" id=\"chkDEL" + tb.Rows[0]["tbMnuCde"].ToString() + "\" value=\"DEL\" checked/>";
                }


            }
            tb.Dispose();


            IzDataSource.Dispose();

        }
    }

    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        Page.ClientScript.RegisterHiddenField("List1_TOPCDE", TOPCDE);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }

    protected void bntSave_Click(object sender, EventArgs e)
    {
        IzDataSource IzDataSource = new IzDataSource();
        IzDataSource.ExecuteSQLNoneQuery("delete from rlGrpMnu where tbGrpCde='" + GrpCde + "'");

        String[] CdeArr = Context.Request.Params["chkSelT"].ToString().Split(',');
        for (int i = 0; i < CdeArr.Length; i++)
        {
            String CdeT = CdeArr[i].Trim();
            if (CdeT != "")
            {
                 String Tmp = "" + Context.Request.Params["BOW" + CdeT].ToString ();

                if (Context.Request.Params["chkADD" + CdeT] != null)
                {
                    Tmp += "," + Context.Request.Params["chkADD" + CdeT].ToString();
                }  
                if (Context.Request.Params["chkEDIT" + CdeT] != null ){
                    Tmp += "," + Context.Request.Params["chkEDIT" + CdeT].ToString();
                }
                if( Context.Request.Params["chkDEL" + CdeT] != null){
                    Tmp += "," + Context.Request.Params["chkDEL" + CdeT].ToString();
                }

                String SqlStr = "insert into rlGrpMnu(tbGrpCde,tbMnuCde,tbMnuPow) values('" + GrpCde + "','" + CdeT + "','" + Tmp + "')";
                IzDataSource.ExecuteSQLNoneQuery(SqlStr);
            }
        }

        WebFormBase.ShowJavaScriptMsgBack(Response, "存檔完畢", "GrpLst.aspx?f=" + Context.Request.QueryString["f"].ToString());
    }
    protected void bntBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("GrpLst.aspx?f=" + Context.Request.QueryString["f"].ToString());
    }
}