﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;

public partial class main_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!this.IsPostBack)
        {
            this.BindRepeater1();
        }
    }
    private void BindRepeater1()
    {
        try
        {
            string constr = ConfigurationManager.ConnectionStrings["SqlSvrStr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select tbStoSub, tbStoCon from tbSto where tbStoTyp = '" + txtType.Text + "'";
                    cmd.Connection = con;
                    con.Open();
                    accRepeater1.DataSource = cmd.ExecuteReader();
                    accRepeater1.DataBind();
                    con.Close();
                }
            }
        }
        catch (Exception ex) { Response.Write(ex.Message); }
    }
}