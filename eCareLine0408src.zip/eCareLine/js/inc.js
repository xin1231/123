﻿//說明：用 JavaScript 實現網頁圖片等比例縮放 
function DrawImage(ImgD,FitWidth,FitHeight) {
   var image=new Image();
   image.src=ImgD.src;
   if(image.width>0 && image.height>0){
      if(image.width/image.height>= FitWidth/FitHeight){
         if(image.width>FitWidth){ 
            ImgD.width=FitWidth;
            ImgD.height=(image.height*FitWidth)/image.width;
         }else{
            ImgD.width=image.width;
            ImgD.height=image.height;
         }
      }else{
         if(image.height>FitHeight){
            ImgD.height=FitHeight;
            ImgD.width=(image.width*FitHeight)/image.height;
         }else{
            ImgD.width=image.width;
            ImgD.height=image.height;
         }
      }
   } 
}

function set_button_key(key){
   //alert(key);
   var button_key = document.getElementById("button_key");
   button_key.value=key;
}

//function set_button_key(key,delpic){
//   var button_key = document.getElementById("button_key");
//   var depic_key  = document.getElementById("delpic");
//   button_key.value=key;
//   depic_key.value =delpic;
//}

var iCount = 0;
function changeText(objElement) {
   var oTextCount = document.getElementById("txtCount");
   var oCount = document.getElementById("hdnCount");
     
   String.prototype.lenB   =   function(){return   this.replace(/[^\x00-\xff]/g,"**").length;}   
   var str = objElement.value;  
     
   iCount = objElement.value.length; // 中文字算一個字的算法
   //iCount = str.lenB();            // 中文字算二個字的算法
   oTextCount.innerHTML = "" + iCount;
   oCount.value = parseInt(iCount);
}

function copy_address(form,value1,value2){
   var cityarea,address,address1,city1,city2;
   if ((value1!="")&&(value2!="")){
     if (value1!=value2){
       cityarea=value1+value2;
     } else {
       cityarea=value1;
     }
     address=form.address.value;
     address1=address;
     if ((address.substr(2,1)=="市")||(address.substr(2,1)=="縣")){
       city1=address.substr(0,3);
       if ((city1=="新竹市")||(city1=="嘉義市")) { address1=address.substr(3,address.length-3); }
     } else { 
       j=address.indexOf("區",3);
       if (j>0) {
         address1=address.substr(j+1,address.length-j); 
       } else {
         j=address.indexOf("市",3);
         if (j>0) {
           address1=address.substr(j+1,address.length-j);
         } else {
           j=address.indexOf("鄉",3);
           if (j>0) {
             address1=address.substr(j+1,address.length-j);
           } else {
             j=address.indexOf("鎮",3);
             if (j>0) {
               address1=address.substr(j+1,address.length-j);
             } else {
               address1=address.substr(3,address.length-3);
             }
           }
         }
       }
     }
   }
   form.address.value=cityarea+address1;
}


function copy_address1(form){ 
   form.address1.value=form.address.value
}

function Buildkey(num) {
   document.Post.area.selectedIndex=0;
   for(ctr=1;ctr<key[num].length;ctr++){
      document.Post.area.options[ctr]=new Option(key[num][ctr],key1[num][ctr]);
   }
   document.Post.area.length=key[num].length;
}

function Clearkeywd() {
}

function call_submit_page(page,sn,ct,url,id) {
   Clearkeywd();
   document.CityArea.Topage.value=page;
   document.CityArea.sn.value=sn;
   document.CityArea.ct.value=ct;
   if (id != null) {
     document.CityArea.action=url+".asp?"+id+"&Topage="+page
   } else {
     document.CityArea.action=url+".asp?Topage="+page
   }
   document.CityArea.submit();
}

function del2maintain(page) {//刊登資料刪除
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   var msg = "確認刪除 " +checkItem + " 筆資料?";
   if (confirm(msg)==true){
     $.ajax({
       url: 'Del2maintain_'+ page + '.asp',
       data: {del_id: checkItem_val},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem + " 筆資料已刪除");
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
}

function del2himg() {//刊登照片刪除
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
      alert("請勾選需要刪除照片");
   } else {
     var msg = "確認刪除 " +checkItem + " 張照片?";
     if (confirm(msg)==true){
       $.ajax({
         url: 'ImgDeleteFile.asp',
         data: {del_id: checkItem_val, ipath: $('#ipath').val(), hid: $('#hid').val()},
         error: function(xhr) {
           alert('Ajax request 發生錯誤');
         },
         success: function(response) {
           if (response == "success") {
             $.blockUI();
             alert(checkItem + " 張照片已刪除");
             setTimeout(function(){location.reload()}, 0);
           } else {
             $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
           }
         }
       });
     }
   }
}

function Add2cover() {//設為首圖
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem > 1) {
      alert("要設定首張圖片，只能選擇一張照片");
   } else {
     $.ajax({
       url: 'Add2cover.asp',
       data: {imgid: checkItem_val, ipath: $('#ipath').val()},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
}

function add2status(page,show) {//刊登狀態
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
      alert("請最少選擇一筆資料");
   } else {
     $.ajax({
       url: 'Add2status_'+ page + '.asp',
       data: {st_id: checkItem_val, st_show: show},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem + " 筆資料已更新");
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
}

function add2sell(page,sell) {//成交狀態
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
      alert("請最少選擇一筆資料");
   } else {
     $.ajax({
       url: 'Add2sell_'+ page + '.asp',
       data: {st_id: checkItem_val, st_sell: sell},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem + " 筆資料已更新");
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
}

function add2ad(page) {//金幣換廣告
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
     alert("請最少選擇一筆需要加強曝光的房屋資料");
   } else {
     linkstr='Add2ad_' + page + '.asp?height=300&width=660';
     linkstr=linkstr+'&ad_id=' + checkItem_val;
     linkstr=linkstr+'&sh_type=1&modal=true';

     //alert(linkstr);
     $.fn.colorbox({title:'金幣換廣告',href:linkstr,height:'auto',width:'900px'});
   }
}

function add2advert(page) {//清單追蹤
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
      alert("請最少選擇一個物件，才能加入追蹤清單喔!!");
   } else {
     $.ajax({
       url: 'add2advert_' + page + '.asp',
       data: {tag_id: checkItem_val},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem+' 筆資料已加入追蹤');
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }  
}

function del2advert(page) {//刪除追蹤資料
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem ==0) {
      alert("請最少選擇一筆資料");
   } else {
   var msg = "確認刪除 " +checkItem + " 筆資料?";
   if (confirm(msg)==true){
     $.ajax({
       url: 'Del2advert_'+ page + '.asp',
       data: {del_id: checkItem_val},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem + " 筆資料已刪除");
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
   }
}

function del2comment(page) {//留言資料刪除
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   var msg = "確認刪除 " +checkItem + " 筆資料?";
   if (confirm(msg)==true){
     $.ajax({
       url: 'Del2comment_'+ page + '.asp',
       data: {del_id: checkItem_val},
       error: function(xhr) {
         alert('Ajax request 發生錯誤');
       },
       success: function(response) {
         if (response == "success") {
           $.blockUI();
           alert(checkItem + " 筆資料已刪除");
           setTimeout(function(){location.reload()}, 0);
         } else {
           $.fn.colorbox({title:'歡迎登入好宅網',href:'member_Login.asp'});
         }
       }
     });
   }
}

function add2contrast(page) {//比較
   var checkItem = $("input[name=chk]:checked").length;
   var checkItem_val = [];
   $("input[name=chk]:checked").each(function(){checkItem_val.push($(this).val());});

   if (checkItem < 2) {
      alert("請選擇一個以上房屋，才能進行比較喔!!");
   } else {
       linkstr='Add2contrast_' + page + '.asp?';
       linkstr=linkstr+'tag_id=' + checkItem_val;
       linkstr=linkstr+'&sh_type=1';

       $.fn.colorbox({title:'物件比較',href:linkstr,height:'500px',width:'800px'});
   }
}