﻿/*檢查欄位是否有值*/
function chkfield(elm,fname){
	if (elm.value==""){
		alert("請輸入 "+fname);
		elm.focus();
		return(false);
	}
	return(true);
}

/*檢查是否為Email格式*/
function chkemail(elm) {
	var c=elm.value.charAt(0);
	if (!((c>="a" && c<="z") || (c>="0" && c<="9") || (c>="A" && c<="Z"))) {
		alert("電子郵件格式錯誤!");
		elm.focus();
		return(false);
	}
	var c=elm.value.charAt(elm.value.length-1);
	if (!((c>="a" && c<="z") || (c>="0" && c<="9") || (c>="A" && c<="Z"))) {
		alert("電子郵件格式錯誤!");
		elm.focus();
		return(false);
	}
	if ((elm.value.indexOf("@")=="-1") || (elm.value.indexOf(".")=="-1")) {
		alert("電子郵件格式錯誤!");
		elm.focus();
		return(false);
	} 
	return(true);
}

/*只可以輸入數字*/
function intpress(elm) {
	if ((event.keyCode!=13) && (event.keyCode != 9) && (event.keyCode != 8) && (event.keyCode != 46) && (event.keyCode != 17) && (event.keyCode != 18)) {
		if (event.keyCode<48 || event.keyCode>57) {
			alert("只能輸入數字");
			elm.focus();
			return false;
		}
	}
	return true;
}

/*檢查是否為數字*/
function isint(elm,msg) {
	var elmstr = elm.value + "";
	for (var i = 0;i<elmstr.length;i++) {
		if (elmstr.charAt(i)<"0" || elmstr.charAt(i)>"9") {
			alert(msg+ " 資料格式錯誤!!");
			elm.focus();
			return false;
		}
	}	
	return true;
}

/*檢查是否為中文字*/
function ischinese(elm,msg) {
	var elmstr = elm.value + "";
	for (var i=0;i<elmstr.length;i++) {
		var ch=escape(elmstr.charAt(i));
		if ((ch.indexOf("%u"))=="-1") {
			alert(msg + " 資料格式錯誤!");
			elm.focus();
			return false;
		}
	}
	return true;
}


/*檢查是否為英數字+連接符號*/
function iseng(elm,msg) {
	for (var i=1;i<elm.value.length-1;i++) {
		var c = elm.value.charAt(i);
		if (!((c>="0" && c<="9") || (c>="a" && c<="z") || (c=="-") || (c>="A" && c<="Z"))) {
			alert(msg + " 資料格式錯誤!!" + c);
			elm.focus();
			return false;
		}
	}
	return true;
}

/*只可以輸入英數字*/
function engpress(elm) {
	if(event.keyCode!=13) {
		if (event.keycode<48 || (event.keyCode>57 && event.keyCode<65) || (event.keyCode>90 && event.keyCode<97) || event.keyCode>122) {
			alert("只能輸入英文或數字!!");
			elm.focus();
			return false;
		}
	}
}

/*檢查資料之Byte數*/
function chkbytes(elm,bytes,msg) {
	var k=0;
	var j=1;
	var chk="Y";
	var elmstr=elm.value + "";
	for (var i=0;i<elmstr.length;i++) {
		var ch=escape(elmstr.charAt(i));
		if ((ch.indexOf("%0D"))!="-1" ||(ch.indexOf("%0A"))!="-1") {
			k=0;
			if((ch.indexOf("%0A"))!="-1") j++;			
		} else if ((ch.indexOf("%u"))!="-1") {
			k=k+2;
		} else {
			k=k+1;
		}
		if (k>bytes) {
			chk="N";
			break;
		}
	}
	if (chk=="N") {
		alert(msg + " 有 " + bytes + " 字元的限制!");
		elm.focus();
		return false;
	}
	return true;
}

function CheckKeypress(eSrc){
  if (eSrc.tagName.toUpperCase()=='INPUT' && eSrc.type.toUpperCase()=='TEXT'){
    var isValidKey = false;
    //這一行只是用來將使用者按下的按鍵所對應的值顯示在狀態列上
    //用不到的話就加註或刪掉
    //window.status = 'key pressed = ' + window.event.keyCode;
    //利用 window.event.keyCode 取得按下的鍵盤按鍵鎖對應的值
    //可依需求修改合法按鍵
    switch(window.event.keyCode){
      case 48:isValidKey=true;break;
      case 49:isValidKey=true;break;
      case 50:isValidKey=true;break;
      case 51:isValidKey=true;break;
      case 52:isValidKey=true;break;
      case 53:isValidKey=true;break;
      case 54:isValidKey=true;break;
      case 55:isValidKey=true;break;
      case 56:isValidKey=true;break;
      case 57:isValidKey=true;break;
    }
    //檢查結束後，利用 window.event.returnValue 來決定是否觸發事件
    //如果 return true，表示觸發事件，使用者打的字就會出現
    //如果 return false，表示事件不觸發，就相當於沒有按過鍵盤按鈕
    window.event.returnValue = isValidKey;
  }
}


function chkidnum(elm){
	if(elm.value==''){
		alert("請填寫身份證字號!!")
		elm.focus()
		return false;
	}
	var LegalID = "0123456789"
	var fResult=true;
	var value = 0;
	var sId=elm.value;
	if(sId.length<10)
		fResult=false;
	else{
      if((sId.charAt(0)=='A') || (sId.charAt(0)=='a')) value=10
      else if((sId.charAt(0)=='B') || (sId.charAt(0)=='b')) value=11
      else if((sId.charAt(0)=='C') || (sId.charAt(0)=='c')) value=12
      else if((sId.charAt(0)=='D') || (sId.charAt(0)=='d')) value=13
      else if((sId.charAt(0)=='E') || (sId.charAt(0)=='e')) value=14
      else if((sId.charAt(0)=='F') || (sId.charAt(0)=='f')) value=15
      else if((sId.charAt(0)=='G') || (sId.charAt(0)=='g')) value=16
      else if((sId.charAt(0)=='H') || (sId.charAt(0)=='h')) value=17
      else if((sId.charAt(0)=='J') || (sId.charAt(0)=='j')) value=18
      else if((sId.charAt(0)=='K') || (sId.charAt(0)=='k')) value=19
      else if((sId.charAt(0)=='L') || (sId.charAt(0)=='l')) value=20
      else if((sId.charAt(0)=='M') || (sId.charAt(0)=='m')) value=21
      else if((sId.charAt(0)=='N') || (sId.charAt(0)=='n')) value=22
      else if((sId.charAt(0)=='P') || (sId.charAt(0)=='p')) value=23
      else if((sId.charAt(0)=='Q') || (sId.charAt(0)=='q')) value=24
      else if((sId.charAt(0)=='R') || (sId.charAt(0)=='r')) value=25
      else if((sId.charAt(0)=='S') || (sId.charAt(0)=='s')) value=26
	  else if((sId.charAt(0)=='T') || (sId.charAt(0)=='t')) value=27
      else if((sId.charAt(0)=='U') || (sId.charAt(0)=='u')) value=28
      else if((sId.charAt(0)=='V') || (sId.charAt(0)=='v')) value=29
      else if((sId.charAt(0)=='X') || (sId.charAt(0)=='x')) value=30
      else if((sId.charAt(0)=='Y') || (sId.charAt(0)=='y')) value=31
      else if((sId.charAt(0)=='W') || (sId.charAt(0)=='w')) value=32
      else if((sId.charAt(0)=='Z') || (sId.charAt(0)=='z')) value=33
      else if((sId.charAt(0)=='I') || (sId.charAt(0)=='i')) value=34
      else if((sId.charAt(0)=='O') || (sId.charAt(0)=='o')) value=35
      else fResult = false ;
      //alert('Value='+value) ;
    }
    if(fResult==true){
	    value = Math.floor(value/10) + (value%10)*9 +
	    parseInt(sId.charAt(1))*8+
	    parseInt(sId.charAt(2))*7+
	    parseInt(sId.charAt(3))*6+
	    parseInt(sId.charAt(4))*5+
	    parseInt(sId.charAt(5))*4+
	    parseInt(sId.charAt(6))*3+
	    parseInt(sId.charAt(7))*2+
	    parseInt(sId.charAt(8))+
	    parseInt(sId.charAt(9)) ;
	    value = value % 10 ;
	    if(value!=0) fResult = false ;
		var i;
		var c;
		for (i = 1; i < sId.length; i++){
			c = sId.charAt(i);
			if (LegalID.indexOf(c) == -1) fResult = false;
		}
	}
	if(fResult == false){
		alert("此身份證字號不正確!")
		elm.focus()
		return false; 
	}
}

/*檢查下拉欄位是否有選擇*/
function chksel(elm,fname){
if (elm.selectedIndex <= 0){
	alert("請先選擇 " + fname);
	elm.focus();
	return(false);
}
return(true);
}

/*切換隱藏或顯示*/
function showhide(obj){
	if (obj.style.display == ""){
		obj.style.display = "none";
	}else{
		obj.style.display = "";
	}

}

/*檢查Rrdo欄位是否有選擇*/
function chkrdo(elm,fname){
  j=0;  
  for (i=0;i<elm.length;i++){
	if (elm[i].checked)
	  j++;
  }
  if (j==0){
    alert("請先選擇 " + fname);
	elm[0].focus();
	return(false);
  }
  else
  {return(true);}
  
}

/*檢查Rdo或Chk欄位是否有選擇*/
function chkRdoChk(obj,msg){ 
   if (obj.length){for (i=0;i<obj.length;i++){if (obj[i]){if (obj[i].checked) return true;}}}
   else{if ( obj.checked )return true;}	  
   alert(msg);
   if (obj.length){obj[0].focus();}else{obj.focus();}
   return false;
}