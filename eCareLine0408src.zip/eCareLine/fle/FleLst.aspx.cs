﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class fle_FleLst : System.Web.UI.Page
{
    public cfg cfg = new cfg();
    IZCls.WebFormBase WebFormBase = new IZCls.WebFormBase();
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();
    IZCls.StringAccess StringAccess = new IZCls.StringAccess();
    LoginUsr LoginUsr;
    mnuDA mnuDA = new mnuDA();

    IZCls.ImageAccess ImageAccess = new IZCls.ImageAccess();
    IZCls.FileAccess FileAccess = new IZCls.FileAccess();

    //'變數宣告
    String STATUS = "";
    String CDE = "";
    int PAGE_INDEX = 1;
    int PAGE_COUNT = 0;
    int REC_COUNT = 0;
    int PAGE_SIZE = 10;
    String SpOrderField = "";
    String SpOrderSort = "";
    int PageCountSize = 10;

    //'權限
    //String POW = "";


    //'宣告
    //'############################################
    //'限制存取檔案類型 "jpg,gif,avi"
    String Str_FileNameExt = "";
    //'限制存取檔案大小 1KB=1024位元組 以位元組為單位
    Int64 Str_ContentLength = 0;
    //'檔案存放位置
    String Str_FilePath = "";
    //'資料表名稱
    String TableName = "";
    //'小縮圖寬
    int Swidth = 0;
    //'中縮圖寬
    int Mwidth = 0;
    //'可解壓縮格式
    String CFormat = "";
    //'###########################################

    //'群組編號
    String GrpCde = "";
    //'選項參數
    String T = ""; //'設定與限制類別
    String S = ""; //'顯示方式

    String CK = "";//CKedit的回插欄位ID

    /// <summary>
    /// 頁面載入時必定優先執行
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        LoginUsr = new LoginUsr(Context);
        LoginUsr.chkLogin();

        //POW = mnuDA.GetPow(LoginUsr.UsrCde, Context.Request.QueryString["f"].ToString());
        //if (mnuDA.ChkPow(POW, "BOW") == false) { WebFormBase.ShowJavaScriptMsgBack(Response, "權限不足", ""); }


        //'設定##############################################################
        //'在這裡放置使用者程式碼以初始化網頁
        if (Context.Request.QueryString["T"] != null) T = DataAccess.ClsSqlChr(Context.Request.QueryString["T"].ToString());
        if (Context.Request.QueryString["CDE"] != null) GrpCde = DataAccess.ClsSqlChr(Context.Request.QueryString["CDE"].ToString());
        if (Context.Request.QueryString["CK"] != null) CK = DataAccess.ClsSqlChr(Context.Request.QueryString["CK"].ToString());

        if (GrpCde == "")
        {
            Response.Write("查無資料");
            Response.End();
        }


        switch (T)
        { //'依選項
            default:
                //'限制存取檔案類型 "jpg,gif,avi"
                Str_FileNameExt = "";// '"jpg,gif,bmp,png,wmv,zip,rar,pptx,ppt,docx,doc";
                //'限制存取檔案大小 1KB=1024位元組 以位元組為單位
                Str_ContentLength = 60720000;
                //'檔案存放位置
                Str_FilePath = "upload/";
                //'資料表名稱
                TableName = "tbFle";
                //'小縮圖寬
                Swidth = 120;
                //'中縮圖寬
                Mwidth = 400;
                //'可解壓縮格式
                CFormat = "zip,rar";

                break;

        }


        lbFileMaxLim.Text = FileAccess.FormateSize(Str_ContentLength, "KB");

        bntSend.Attributes.Add("onclick", "if (document.getElementById('" + txtFleSub.ClientID + "').value=='') { if (confirm('說明未填寫,確定要上傳?')) {} else {return false;} }");

        //'###################################################################





        //'--Start--取得隨頁隱藏欄位資訊
        if (Context.Request.Params["List1_STATUS"] != null) STATUS = DataAccess.ClsSqlChr(Context.Request.Params["List1_STATUS"].ToString()); //'頁面狀態

        if (Context.Request.Params["List1_CDE"] != null) CDE = DataAccess.ClsSqlChr(Context.Request.Params["List1_CDE"].ToString()); //'目前資料編號

        if (Context.Request.Params["List1_PAGE"] != null)
        {
            if (Context.Request.Params["List1_PAGE"].ToString() != "" && StringAccess.IsNum(Context.Request.Params["List1_PAGE"].ToString()))
            {
                PAGE_INDEX = Convert.ToInt32(Context.Request.Params["List1_PAGE"].ToString()); //'目前清單頁數
                if (PAGE_INDEX < 1) PAGE_INDEX = 1;
            }
        }

        if (txtPageSize.Text != "" && StringAccess.IsNum(txtPageSize.Text))
        {
            PAGE_SIZE = Convert.ToInt32(txtPageSize.Text); //'每頁筆數
            if (PAGE_SIZE < 1) PAGE_SIZE = 1;
        }

        if (Context.Request.Params["List1_SORTFD"] != null) SpOrderField = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORTFD"].ToString()); //'取排序欄位

        if (Context.Request.Params["List1_SORT"] != null) SpOrderSort = DataAccess.ClsSqlChr(Context.Request.Params["List1_SORT"].ToString()); //'取排序升降
        if (SpOrderSort != "ASC" && SpOrderSort != "DESC")
        {
            SpOrderSort = "";
        }
        //'--End--取得隨頁隱藏欄位資訊


        if (!IsPostBack)
        { //'頁面首次載入實執行

            //if (Context.Request.QueryString["f"] != null) lbSubTitle.Text = mnuDA.GenPageTitle(Context.Request.QueryString["f"].ToString());

            ShowData();
        }
        else
        {
            if (STATUS != "")
            { //'狀態非空白時執行(空白時為按鈕事件)
                ShowData();
            }
        }


    }

    /// <summary>
    /// 新增刪除修改檢視及清單處理
    /// </summary>
    void ShowData()
    {

        //'-- Part 1 -- ：資料處理
        switch (STATUS)
        {

            case "": //'清單顯示
                {
                    ltStuTitle.Text = "清單";
                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.ParametersClear();


                    //'設定基本語法
                    String SqlStr = "select tbFleCde from tbFle where tbGrpCde=@tbGrpCde ";

                    IzDataSource.ParametersAdd("tbGrpCde", GrpCde);

                    //'檢視是否需要加上查詢條件
                    if (txtWhat.Text != "")
                    {
                        SqlStr += " and " + SelItem.SelectedValue + " like @SelValue";
                        IzDataSource.ParametersAdd("SelValue", "%" + txtWhat.Text + "%");
                    }

                    //'排序
                    String OrderBy = ""; //'基本排序

                    //'設定排序條件
                    String OrderByA = "";
                    if (SpOrderField != "" && OrderBy != "")
                    {
                        if (OrderBy.IndexOf(SpOrderField) > -1)
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort;
                        }
                        else
                        {
                            OrderByA = SpOrderField + " " + SpOrderSort + " , " + OrderBy;
                        }
                    }
                    else if (SpOrderField != "")
                    {
                        OrderByA = SpOrderField + " " + SpOrderSort;
                    }
                    else if (OrderBy != "")
                    {
                        OrderByA = OrderBy;
                    }


                    if (OrderByA != "")
                    {
                        SqlStr += " order by " + OrderByA;
                    }

                    //'設定查詢字串
                    IzDataSource.SelectString = SqlStr;

                    //'取得資料結果
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();

                    //'取得總筆數
                    REC_COUNT = tb.Rows.Count;
                    if (REC_COUNT < 0) REC_COUNT = 0;

                    //'計算總頁數
                    if (REC_COUNT > 0)
                    {
                        if ((REC_COUNT % PAGE_SIZE) == 0)
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE);
                        }
                        else
                        {
                            PAGE_COUNT = (REC_COUNT / PAGE_SIZE) + 1;
                        }
                    }

                    lbDataTotPage.Text = PAGE_COUNT.ToString(); //'顯示總頁數

                    if (PAGE_INDEX > PAGE_COUNT) PAGE_INDEX = PAGE_COUNT;

                    lbDataPage.Items.Clear();
                    for (int x = 1; x <= PAGE_COUNT; x++)
                    {
                        lbDataPage.Items.Add(x.ToString());
                    }
                    if (lbDataPage.Items.Count < 1) lbDataPage.Items.Add("0");
                    lbDataPage.Text = PAGE_INDEX.ToString(); //'顯示目前頁碼
                    lbDataCount.Text = REC_COUNT.ToString(); //'顯示資料總筆數


                    //'取得需顯示頁面編號
                    System.Data.DataTable tbR = new System.Data.DataTable();
                    tbR.Columns.Add(new System.Data.DataColumn(tb.Columns[0].ColumnName));
                    if (REC_COUNT > 0)
                    {
                        int S_index = (PAGE_INDEX - 1) * PAGE_SIZE;
                        int E_index = (PAGE_INDEX * PAGE_SIZE) - 1;
                        if (E_index > (REC_COUNT - 1)) E_index = REC_COUNT - 1;
                        for (int i = S_index; i <= E_index; i++)
                        {
                            tbR.Rows.Add(tb.Rows[i][0].ToString());
                        }
                    }


                    //'將資料結合到DataList清單顯示元件
                    Repeater1.DataSource = tbR; //'設定資料來源
                    Repeater1.DataBind(); //'清單資料開始組合

                    tb.Dispose();
                    tbR.Dispose();


                    //''取分頁設定
                    System.Data.DataTable tbPage = DataAccess.GetPageLstToTable(REC_COUNT, PAGE_SIZE, PAGE_INDEX.ToString(), PageCountSize);
                    DataListPage.DataSource = DataAccess.SetPageLstUrl(tbPage, "List1");
                    DataListPage.DataBind();




                    IzDataSource.Dispose();
                }

                break;

            case "ADD": //'新增畫面
                {
                    ltStuTitle.Text = "新增";

                    txttbFleCde.Text = "" + cfg.getcde("FLE");
                    //txttbGrpCde.Text = "";
                    txttbFleTop.Text = "";
                    txttbFleSub.Text = "";
                    txttbFleCon.Text = "";
                    //txttbFleNot.Text = "";
                    //txttbFleNme.Text = "";
                    //txttbFleTpf.Text = "";
                    //txttbFleSiz.Text = "";
                    //txttbFleExt.Text = "";
                    //txttbFleUtp.Text = "";
                    //txttbFlePath.Text = "";
                    //txttbFleImg.Text = "";
                    //txttbFleClk.Text = "";
                    //txttbFleFlg.Text = "";
                    //WebFormBase.GenRdoList(txttbFleFlg, cfg.FlgNmeArr, cfg.FlgValArr, "1");
                    //txttbFleCdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    //txttbFleMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                    //txttbFleCid.Text = LoginUsr.UsrCde;
                    //txttbFleMid.Text = "";
                    //txttbFleCip.Text = Context.Request.UserHostAddress;
                    //txttbFleMip.Text = "";


                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"

                }
                break;

            case "ADDSAV": //'新增存檔
                {
                    //'取HTML編輯模組傳回值
                    //'String tbUsrAre = Context.Request.Params["ctl00$ContentPlaceHolder1$txttbUsrAre_A"].ToString();

                    String tbFleCde = txttbFleCde.Text;
                    //String tbGrpCde = txttbGrpCde.Text;
                    String tbFleTop = txttbFleTop.Text;
                    String tbFleSub = txttbFleSub.Text;
                    String tbFleCon = txttbFleCon.Text;
                    //String tbFleNot = txttbFleNot.Text;
                    //String tbFleNme = txttbFleNme.Text;
                    //String tbFleTpf = txttbFleTpf.Text;
                    //String tbFleSiz = txttbFleSiz.Text;
                    //String tbFleExt = txttbFleExt.Text;
                    //String tbFleUtp = txttbFleUtp.Text;
                    //String tbFlePath = txttbFlePath.Text;
                    //String tbFleImg = txttbFleImg.Text;
                    //String tbFleClk = txttbFleClk.Text;
                    //String tbFleFlg = txttbFleFlg.Text;
                    //String tbFleCdt = txttbFleCdt.Text;
                    //String tbFleMdt = txttbFleMdt.Text;
                    //String tbFleCid = txttbFleCid.Text;
                    //String tbFleMid = txttbFleMid.Text;
                    //String tbFleCip = txttbFleCip.Text;
                    //String tbFleMip = txttbFleMip.Text;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.InsertCommand = "insert into tbFle("
                    + "tbFleCde"
                    + ",tbGrpCde"
                    + ",tbFleTop"
                    + ",tbFleSub"
                    + ",tbFleCon"
                    + ",tbFleNot"
                    + ",tbFleNme"
                    + ",tbFleTpf"
                    + ",tbFleSiz"
                    + ",tbFleExt"
                    + ",tbFleUtp"
                    + ",tbFlePath"
                    + ",tbFleImg"
                    + ",tbFleClk"
                    + ",tbFleFlg"
                    + ",tbFleCdt"
                    + ",tbFleMdt"
                    + ",tbFleCid"
                    + ",tbFleMid"
                    + ",tbFleCip"
                    + ",tbFleMip"
                    + ") values("
                    + "@tbFleCde"
                    + ",@tbGrpCde"
                    + ",@tbFleTop"
                    + ",@tbFleSub"
                    + ",@tbFleCon"
                    + ",@tbFleNot"
                    + ",@tbFleNme"
                    + ",@tbFleTpf"
                    + ",@tbFleSiz"
                    + ",@tbFleExt"
                    + ",@tbFleUtp"
                    + ",@tbFlePath"
                    + ",@tbFleImg"
                    + ",@tbFleClk"
                    + ",@tbFleFlg"
                    + ",@tbFleCdt"
                    + ",@tbFleMdt"
                    + ",@tbFleCid"
                    + ",@tbFleMid"
                    + ",@tbFleCip"
                    + ",@tbFleMip"
                    + ")";
                    IzDataSource.InsertParameters.Add("tbFleCde", tbFleCde);
                    //IzDataSource.InsertParameters.Add("tbGrpCde", tbGrpCde);
                    IzDataSource.InsertParameters.Add("tbFleTop", tbFleTop);
                    IzDataSource.InsertParameters.Add("tbFleSub", tbFleSub);
                    IzDataSource.InsertParameters.Add("tbFleCon", tbFleCon);
                    //IzDataSource.InsertParameters.Add("tbFleNot", tbFleNot);
                    //IzDataSource.InsertParameters.Add("tbFleNme", tbFleNme);
                    //IzDataSource.InsertParameters.Add("tbFleTpf", tbFleTpf);
                    //IzDataSource.InsertParameters.Add("tbFleSiz", tbFleSiz);
                    //IzDataSource.InsertParameters.Add("tbFleExt", tbFleExt);
                    //IzDataSource.InsertParameters.Add("tbFleUtp", tbFleUtp);
                    //IzDataSource.InsertParameters.Add("tbFlePath", tbFlePath);
                    //IzDataSource.InsertParameters.Add("tbFleImg", tbFleImg);
                    //IzDataSource.InsertParameters.Add("tbFleClk", tbFleClk);
                    //IzDataSource.InsertParameters.Add("tbFleFlg", tbFleFlg);
                    //IzDataSource.InsertParameters.Add("tbFleCdt", tbFleCdt);
                    //IzDataSource.InsertParameters.Add("tbFleMdt", tbFleMdt);
                    //IzDataSource.InsertParameters.Add("tbFleCid", tbFleCid);
                    //IzDataSource.InsertParameters.Add("tbFleMid", tbFleMid);
                    //IzDataSource.InsertParameters.Add("tbFleCip", tbFleCip);
                    //IzDataSource.InsertParameters.Add("tbFleMip", tbFleMip);

                    //IzDataSource.Insert();
                    IzDataSource.Dispose();
                }
                break;

            case "EDIT": //'修改畫面
                {
                    ltStuTitle.Text = "修改";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbFle where tbFleCde=@tbFleCde";
                    IzDataSource.ParametersAdd("tbFleCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        txttbFleCde.Text = tb.Rows[0]["tbFleCde"].ToString();
                        //txttbGrpCde.Text = tb.Rows[0]["tbGrpCde"].ToString();
                        //txttbFleTop.Text = tb.Rows[0]["tbFleTop"].ToString();
                        WebFormBase.GenRdoList(txttbFleTop, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbFleTop"].ToString());
                        txttbFleSub.Text = tb.Rows[0]["tbFleSub"].ToString();
                        txttbFleCon.Text = tb.Rows[0]["tbFleCon"].ToString();
                        //txttbFleNot.Text = tb.Rows[0]["tbFleNot"].ToString();
                        //txttbFleNme.Text = tb.Rows[0]["tbFleNme"].ToString();
                        //txttbFleTpf.Text = tb.Rows[0]["tbFleTpf"].ToString();
                        //txttbFleSiz.Text = tb.Rows[0]["tbFleSiz"].ToString();
                        //txttbFleExt.Text = tb.Rows[0]["tbFleExt"].ToString();
                        //txttbFleUtp.Text = tb.Rows[0]["tbFleUtp"].ToString();
                        //txttbFlePath.Text = tb.Rows[0]["tbFlePath"].ToString();
                        //txttbFleImg.Text = tb.Rows[0]["tbFleImg"].ToString();
                        //txttbFleClk.Text = tb.Rows[0]["tbFleClk"].ToString();
                        ////txttbFleFlg.Text = tb.Rows[0]["tbFleFlg"].ToString();
                        //WebFormBase.GenRdoList(txttbFleFlg, cfg.FlgNmeArr, cfg.FlgValArr, tb.Rows[0]["tbFleFlg"].ToString());
                        //txttbFleCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbFleCdt"]).ToString("yyyy/MM/dd HH:mm:ss");
                        //txttbFleMdt.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        //txttbFleCid.Text = tb.Rows[0]["tbFleCid"].ToString();
                        //txttbFleMid.Text = LoginUsr.UsrCde;
                        //txttbFleCip.Text = tb.Rows[0]["tbFleCip"].ToString();
                        //txttbFleMip.Text = Context.Request.UserHostAddress;

                    }
                    tb.Dispose();

                    //'檔案上傳使用iframe 並如下設定網址
                    //'txtFile.Text = "<iframe frameborder=\"0\" width=\"100%\" height=\"300\" src=\"../fle/FleLst.aspx?CDE=" + txttbBodCde.Text + "\"></iframe>"


                }
                break;

            case "EDITSAV": //'修改存檔
                {

                    String tbFleCde = txttbFleCde.Text;
                    //String tbGrpCde = txttbGrpCde.Text;
                    String tbFleTop = txttbFleTop.Text;
                    String tbFleSub = txttbFleSub.Text;
                    String tbFleCon = txttbFleCon.Text;
                    //String tbFleNot = txttbFleNot.Text;
                    //String tbFleNme = txttbFleNme.Text;
                    //String tbFleTpf = txttbFleTpf.Text;
                    //String tbFleSiz = txttbFleSiz.Text;
                    //String tbFleExt = txttbFleExt.Text;
                    //String tbFleUtp = txttbFleUtp.Text;
                    //String tbFlePath = txttbFlePath.Text;
                    //String tbFleImg = txttbFleImg.Text;
                    //String tbFleClk = txttbFleClk.Text;
                    //String tbFleFlg = txttbFleFlg.Text;
                    //String tbFleCdt = txttbFleCdt.Text;
                    String tbFleMdt = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"); //txttbFleMdt.Text;
                    //String tbFleCid = txttbFleCid.Text;
                    String tbFleMid = LoginUsr.UsrCde;
                    //String tbFleCip = txttbFleCip.Text;
                    String tbFleMip = Context.Request.UserHostAddress;

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.UpdateCommand = "update tbFle set "
                    + "tbFleTop=@tbFleTop"
                    + ",tbFleSub=@tbFleSub"
                    + ",tbFleCon=@tbFleCon"
                    + ",tbFleMdt=@tbFleMdt"
                    + ",tbFleMid=@tbFleMid"
                    + ",tbFleMip=@tbFleMip"
                    + " where tbFleCde=@tbFleCde";
                    IzDataSource.UpdateParameters.Add("tbFleCde", tbFleCde);
                    //IzDataSource.UpdateParameters.Add("tbGrpCde", tbGrpCde);
                    IzDataSource.UpdateParameters.Add("tbFleTop", tbFleTop);
                    IzDataSource.UpdateParameters.Add("tbFleSub", tbFleSub);
                    IzDataSource.UpdateParameters.Add("tbFleCon", tbFleCon);
                    //IzDataSource.UpdateParameters.Add("tbFleNot", tbFleNot);
                    //IzDataSource.UpdateParameters.Add("tbFleNme", tbFleNme);
                    //IzDataSource.UpdateParameters.Add("tbFleTpf", tbFleTpf);
                    //IzDataSource.UpdateParameters.Add("tbFleSiz", tbFleSiz);
                    //IzDataSource.UpdateParameters.Add("tbFleExt", tbFleExt);
                    //IzDataSource.UpdateParameters.Add("tbFleUtp", tbFleUtp);
                    //IzDataSource.UpdateParameters.Add("tbFlePath", tbFlePath);
                    //IzDataSource.UpdateParameters.Add("tbFleImg", tbFleImg);
                    //IzDataSource.UpdateParameters.Add("tbFleClk", tbFleClk);
                    //IzDataSource.UpdateParameters.Add("tbFleFlg", tbFleFlg);
                    //IzDataSource.UpdateParameters.Add("tbFleCdt", tbFleCdt);
                    IzDataSource.UpdateParameters.Add("tbFleMdt", tbFleMdt);
                    //IzDataSource.UpdateParameters.Add("tbFleCid", tbFleCid);
                    IzDataSource.UpdateParameters.Add("tbFleMid", tbFleMid);
                    //IzDataSource.UpdateParameters.Add("tbFleCip", tbFleCip);
                    IzDataSource.UpdateParameters.Add("tbFleMip", tbFleMip);

                    IzDataSource.Update();
                    IzDataSource.Dispose();
                }
                break;

            case "DELALL": //'多選刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    String SelT = Context.Request.Params["chkSelT"].ToString();
                    String[] SelTArr = SelT.Split(',');
                    for (int i = 0; i < SelTArr.Length; i++)
                    {

                        //'刪除
                        //IzDataSource.DeleteCommand = "delete from tbFle where tbFleCde=@tbFleCde";
                        //IzDataSource.DeleteParameters.Clear();
                        //IzDataSource.DeleteParameters.Add("tbFleCde", SelTArr[i]);
                        //IzDataSource.Delete();

                        String StrSql = "select tbFleCde,tbGrpCde,tbFleUtp,tbFlePath,tbFleNme,tbFleExt from tbFle where tbFleCde='" + SelTArr[i] + "'";
                        System.Data.DataTable tbfle = IzDataSource.GenDataTable(StrSql);

                        if (tbfle.Rows.Count > 0)
                        {
                            if (tbfle.Rows[0]["tbFleUtp"].ToString() == "file")
                            { //'需刪檔案
                                String F_NewFileName = "";
                                if (tbfle.Rows[0]["tbFleExt"].ToString() != "")
                                {
                                    F_NewFileName = tbfle.Rows[0]["tbFleCde"].ToString() + "." + tbfle.Rows[0]["tbFleExt"].ToString();
                                }
                                else
                                {
                                    F_NewFileName = tbfle.Rows[0]["tbFleCde"].ToString();
                                }

                                if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName))
                                {
                                    System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName);
                                }
                                if (tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "jpg" || tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "gif" || tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "png")
                                {
                                    String F_NewFileNameS = "";
                                    F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_S" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                                    if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS))
                                    {
                                        System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS);
                                    }
                                    F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_M" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                                    if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS))
                                    {
                                        System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS);
                                    }
                                }

                            }
                        }
                        String SQLSTR = "delete from tbfle where tbflecde='" + SelTArr[i] + "'";
                        IzDataSource.ExecuteSQLNoneQuery(SQLSTR);

                        tbfle.Dispose();




                    }

                    IzDataSource.Dispose();
                }
                break;

            case "DELONE": //'單筆刪除
                {
                    IzDataSource IzDataSource = new IzDataSource();

                    //'刪除
                    //IzDataSource.DeleteCommand = "delete from tbFle where tbFleCde=@tbFleCde";
                    //IzDataSource.DeleteParameters.Clear();
                    //IzDataSource.DeleteParameters.Add("tbFleCde", CDE);
                    //IzDataSource.Delete();


                    String DELCDE = CDE;

                    String StrSql = "select tbFleCde,tbGrpCde,tbFleUtp,tbFlePath,tbFleNme,tbFleExt from tbFle where tbFleCde='" + DELCDE + "'";
                    System.Data.DataTable tbfle = IzDataSource.GenDataTable(StrSql);

                    if (tbfle.Rows.Count > 0)
                    {
                        if (tbfle.Rows[0]["tbFleUtp"].ToString() == "file")
                        { //'需刪檔案
                            String F_NewFileName = "";
                            if (tbfle.Rows[0]["tbFleExt"].ToString() != "")
                            {
                                F_NewFileName = tbfle.Rows[0]["tbFleCde"].ToString() + "." + tbfle.Rows[0]["tbFleExt"].ToString();
                            }
                            else
                            {
                                F_NewFileName = tbfle.Rows[0]["tbFleCde"].ToString();
                            }

                            if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName))
                            {
                                System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName);
                            }
                            if (tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "jpg" || tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "gif" || tbfle.Rows[0]["tbFleExt"].ToString().ToLower() == "png")
                            {
                                String F_NewFileNameS = "";
                                F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_S" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                                if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS))
                                {
                                    System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS);
                                }
                                F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_M" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                                if (System.IO.File.Exists(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS))
                                {
                                    System.IO.File.Delete(Server.MapPath(tbfle.Rows[0]["tbFlePath"].ToString()) + tbfle.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileNameS);
                                }
                            }

                        }
                    }
                    String SQLSTR = "delete from tbfle where tbflecde='" + DELCDE + "'";
                    IzDataSource.ExecuteSQLNoneQuery(SQLSTR);

                    tbfle.Dispose();


                    IzDataSource.Dispose();
                }
                break;
            case "VIEW": //'單筆檢視
                {
                    ltStuTitle.Text = "檢視";

                    IzDataSource IzDataSource = new IzDataSource();
                    IzDataSource.SelectString = "select * from tbFle where tbFleCde=@tbFleCde";
                    IzDataSource.ParametersAdd("tbFleCde", CDE);
                    System.Data.DataTable tb = IzDataSource.SelectDataTable();
                    IzDataSource.Dispose();
                    if (tb.Rows.Count > 0)
                    {

                        lbtbFleCde.Text = tb.Rows[0]["tbFleCde"].ToString();
                        lbtbGrpCde.Text = tb.Rows[0]["tbGrpCde"].ToString();
                        lbtbFleTop.Text = tb.Rows[0]["tbFleTop"].ToString();
                        lbtbFleSub.Text = tb.Rows[0]["tbFleSub"].ToString();
                        lbtbFleCon.Text = tb.Rows[0]["tbFleCon"].ToString();
                        lbtbFleNot.Text = tb.Rows[0]["tbFleNot"].ToString();
                        lbtbFleNme.Text = tb.Rows[0]["tbFleNme"].ToString();
                        lbtbFleTpf.Text = tb.Rows[0]["tbFleTpf"].ToString();
                        lbtbFleSiz.Text = tb.Rows[0]["tbFleSiz"].ToString();
                        lbtbFleExt.Text = tb.Rows[0]["tbFleExt"].ToString();
                        lbtbFleUtp.Text = tb.Rows[0]["tbFleUtp"].ToString();
                        lbtbFlePath.Text = tb.Rows[0]["tbFlePath"].ToString();
                        lbtbFleImg.Text = tb.Rows[0]["tbFleImg"].ToString();
                        lbtbFleClk.Text = tb.Rows[0]["tbFleClk"].ToString();
                        lbtbFleFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbFleFlg"].ToString());
                        lbtbFleCdt.Text = tb.Rows[0]["tbFleCdt"].ToString();
                        lbtbFleMdt.Text = tb.Rows[0]["tbFleMdt"].ToString();
                        lbtbFleCid.Text = tb.Rows[0]["tbFleCid"].ToString();
                        lbtbFleMid.Text = tb.Rows[0]["tbFleMid"].ToString();
                        lbtbFleCip.Text = tb.Rows[0]["tbFleCip"].ToString();
                        lbtbFleMip.Text = tb.Rows[0]["tbFleMip"].ToString();

                    }
                    tb.Dispose();
                }
                break;

            default:

                //'不明狀態不處理

                break;
        }


        //'-- Part 2 -- ：顯示處理
        switch (STATUS)
        {
            case "": //'清單狀態
                LIST.Visible = true;
                UPDATE.Visible = false;
                VIEW.Visible = false;

                //'全選
                lnSelAll.NavigateUrl = "javascript:SelAllchk(true);";
                //'全不選
                lnNoSelAll.NavigateUrl = "javascript:SelAllchk(false);";
                //'選擇刪除
                lnSelDel.NavigateUrl = "javascript:goDelSel('List1','');";
                //'新增
                lnADD.NavigateUrl = "javascript:chgValSubmit('List1','ADD');";
                lnADD.Visible = false;
                //'查詢欄位
                txtWhat.Attributes["onkeypress"] = "if (event.keyCode == 13) {chgValSubmit('List1','SEARCH');return false;}";
                bntSearch.Attributes["onclick"] = "chgVal('List1_STATUS', 'SEARCH')";
                //'重新整理
                lnReFrash.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH');";
                //'換頁
                lbDataPage.Attributes["onchange"] = "chgVal('List1_PAGE',this.value);chgValSubmit('List1','SEARCH');";
                break;
            case "ADD": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','ADDSAV');";
                //'ADD返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "EDIT": //'新增填資料狀態
                LIST.Visible = false;
                UPDATE.Visible = true;
                VIEW.Visible = false;

                lnSend.NavigateUrl = "javascript:chkFormSubmit('List1','EDITSAV');";
                //'EDIT返回按鈕
                lnEditBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "VIEW": //'檢視狀態
                LIST.Visible = false;
                UPDATE.Visible = false;
                VIEW.Visible = true;

                //'VIEW返回按鈕
                lnViewBack.NavigateUrl = "javascript:chgValSubmit('List1','SEARCH')";
                break;
            case "ADDSAV":
            case "EDITSAV":
            case "DELONE":
            case "DELALL":
            case "SEARCH": //'還原為清單處理
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            case "SORT": //'排序
                if (SpOrderSort == "ASC")
                {
                    SpOrderSort = "DESC";
                }
                else
                {
                    SpOrderSort = "ASC";
                }
                STATUS = "";
                ShowData(); //'重新呼叫執行清單狀態
                break;
            default:
                //'不明狀態不處理
                break;
        }

    }



    /// <summary>
    /// 搜尋按紐
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void bntSearch_Click(object sender, EventArgs e)
    {
        PAGE_INDEX = 1;//'設定回第一頁
        ShowData();
    }


    /// <summary>
    /// 清單每筆顯示處理
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {

            System.Data.DataRowView dr = (System.Data.DataRowView)e.Item.DataItem;

            //'取資料
            IzDataSource IzDataSource = new IzDataSource();
            System.Data.DataTable tb = IzDataSource.GenDataTable("select * from tbFle where tbFleCde='" + dr["tbFleCde"].ToString() + "'");
            if (tb.Rows.Count > 0)
            {

                Label lbXtbFleCde = (Label)e.Item.FindControl("lbXtbFleCde"); //tbFleCde
                //Label lbXtbGrpCde = (Label)e.Item.FindControl("lbXtbGrpCde"); //tbGrpCde
                Label lbXtbFleTop = (Label)e.Item.FindControl("lbXtbFleTop"); //tbFleTop
                Label lbXtbFleSub = (Label)e.Item.FindControl("lbXtbFleSub"); //tbFleSub
                //Label lbXtbFleCon = (Label)e.Item.FindControl("lbXtbFleCon"); //tbFleCon
                //Label lbXtbFleNot = (Label)e.Item.FindControl("lbXtbFleNot"); //tbFleNot
                //Label lbXtbFleNme = (Label)e.Item.FindControl("lbXtbFleNme"); //tbFleNme
                //Label lbXtbFleTpf = (Label)e.Item.FindControl("lbXtbFleTpf"); //tbFleTpf
                Label lbXtbFleSiz = (Label)e.Item.FindControl("lbXtbFleSiz"); //tbFleSiz
                Label lbXtbFleExt = (Label)e.Item.FindControl("lbXtbFleExt"); //tbFleExt
                //Label lbXtbFleUtp = (Label)e.Item.FindControl("lbXtbFleUtp"); //tbFleUtp
                //Label lbXtbFlePath = (Label)e.Item.FindControl("lbXtbFlePath"); //tbFlePath
                //Label lbXtbFleImg = (Label)e.Item.FindControl("lbXtbFleImg"); //tbFleImg
                Label lbXtbFleClk = (Label)e.Item.FindControl("lbXtbFleClk"); //tbFleClk
                //Label lbXtbFleFlg = (Label)e.Item.FindControl("lbXtbFleFlg"); //tbFleFlg
                Label lbXtbFleCdt = (Label)e.Item.FindControl("lbXtbFleCdt"); //tbFleCdt

                HyperLink lnVIEW = (HyperLink)e.Item.FindControl("lnVIEW"); //'檢視
                HyperLink lnEDIT = (HyperLink)e.Item.FindControl("lnEDIT"); //'修改
                HyperLink lnDEL = (HyperLink)e.Item.FindControl("lnDEL"); //'刪除

                HyperLink lnInsPic = (HyperLink)e.Item.FindControl("lnInsPic");
                HyperLink lnInsFle = (HyperLink)e.Item.FindControl("lnInsFle");

                lbXtbFleCde.Text = tb.Rows[0]["tbFleCde"].ToString();
                //lbXtbGrpCde.Text = tb.Rows[0]["tbGrpCde"].ToString();
                lbXtbFleTop.Text = cfg.getFlgNme(tb.Rows[0]["tbFleTop"].ToString());
                lbXtbFleSub.Text = tb.Rows[0]["tbFleSub"].ToString();
                //lbXtbFleCon.Text = tb.Rows[0]["tbFleCon"].ToString();
                //lbXtbFleNot.Text = tb.Rows[0]["tbFleNot"].ToString();
                //lbXtbFleNme.Text = tb.Rows[0]["tbFleNme"].ToString();
                //lbXtbFleTpf.Text = tb.Rows[0]["tbFleTpf"].ToString();
                lbXtbFleSiz.Text = FileAccess.FormateSize(Convert.ToInt64(tb.Rows[0]["tbFleSiz"]), "KB");
                lbXtbFleExt.Text = tb.Rows[0]["tbFleExt"].ToString();
                //lbXtbFleUtp.Text = tb.Rows[0]["tbFleUtp"].ToString();
                //lbXtbFlePath.Text = tb.Rows[0]["tbFlePath"].ToString();
                //lbXtbFleImg.Text = tb.Rows[0]["tbFleImg"].ToString();
                lbXtbFleClk.Text = tb.Rows[0]["tbFleClk"].ToString();
                //lbXtbFleFlg.Text = cfg.getFlgNme(tb.Rows[0]["tbFleFlg"].ToString());
                lbXtbFleCdt.Text = Convert.ToDateTime(tb.Rows[0]["tbFleCdt"]).ToString("yyyy/MM/dd") + "<br />" + Convert.ToDateTime(tb.Rows[0]["tbFleCdt"]).ToString("HH:mm:ss");

                lnVIEW.NavigateUrl = "FleGet.aspx?CDE=" + tb.Rows[0]["tbFleCde"].ToString() + "";
                lnVIEW.Target = "_blank";
                lnEDIT.NavigateUrl = "javascript:goEdit('List1','" + tb.Rows[0]["tbFleCde"].ToString() + "')";
                lnDEL.NavigateUrl = "javascript:goDelOne('List1','" + tb.Rows[0]["tbFleCde"].ToString() + "','" + tb.Rows[0]["tbFleSub"].ToString() + "')";

                String picT = "<img src=\"../fle/FleGet.aspx?CDE=" + tb.Rows[0]["tbFleCde"].ToString() + "\" hspace=\"10\" vspace=\"10\" alt=\"" + tb.Rows[0]["tbFleSub"].ToString() + "\" />";
                //lnInsPic.NavigateUrl = "javascript:parent.$.fn.colorbox.close();parent.tinyMCE.execCommand('mceInsertContent',false,'" + picT + "');";
                if (CK == "")
                {
                    lnInsPic.NavigateUrl = "javascript:parent.tinyMCE.execCommand('mceInsertContent',false,'" + picT + "');";
                }
                else{
                    lnInsPic.NavigateUrl = "javascript:parent.CKEDITOR.instances." + CK + ".insertHtml('" + picT + "');";
                }
                String fleT = "<a href=\"../fle/FleGet.aspx?CDE=" + tb.Rows[0]["tbFleCde"].ToString() + "\" >[" + tb.Rows[0]["tbFleSub"].ToString() + "]</a>";
                //lnInsFle.NavigateUrl = "javascript:parent.$.fn.colorbox.close();parent.tinyMCE.execCommand('mceInsertContent',false,'" + fleT + "');";
                if (CK == "")
                {
                    lnInsFle.NavigateUrl = "javascript:parent.tinyMCE.execCommand('mceInsertContent',false,'" + fleT + "');";
                }
                else
                {
                    lnInsFle.NavigateUrl = "javascript:parent.CKEDITOR.instances." + CK + ".insertHtml('" + fleT + "');";
                }

     
            }
            tb.Dispose();
            IzDataSource.Dispose();
        }
    }


    protected void Page_LoadComplete(object sender, EventArgs e)
    {
        //'結束時產生狀態隱藏欄位
        Page.ClientScript.RegisterHiddenField("List1_STATUS", STATUS);
        Page.ClientScript.RegisterHiddenField("List1_CDE", CDE);
        Page.ClientScript.RegisterHiddenField("List1_PAGE", PAGE_INDEX.ToString());
        Page.ClientScript.RegisterHiddenField("List1_SORTFD", SpOrderField);
        Page.ClientScript.RegisterHiddenField("List1_SORT", SpOrderSort);
        txtPageSize.Text = PAGE_SIZE.ToString();

    }


    protected void bntSend_Click(object sender, EventArgs e)
    {

        if (FileUpload1.FileName == "")
        {
            return;
        }


        //'取得自動編號
        String CDEA = cfg.getcde("FLE");

        //'完整路徑檔名
        String F_FilePathName = FileUpload1.FileName;
        //'檔案類型
        String F_ContentType = FileUpload1.PostedFile.ContentType;
        //'檔案大小
        Int64 F_ContentLength = FileUpload1.PostedFile.ContentLength;
        //'檔案名稱
        String F_FileName = F_FilePathName.Substring(F_FilePathName.LastIndexOf("\\") + 1);
        //'副檔名
        String F_FileNameExt = F_FileName.Substring(F_FileName.LastIndexOf(".") + 1);


        //'檢查檔案是否過大
        if (F_ContentLength > Str_ContentLength)
        {
            WebFormBase.ShowJavaScriptMsgBack(Response, "檔案大小超過限制!!", "");
        }

        //'檢查檔案是否符合類型
        if (Str_FileNameExt != "")
        {
            if (Str_FileNameExt.ToLower().IndexOf(F_FileNameExt.ToLower()) >= 0)
            {
            }
            else
            {
                WebFormBase.ShowJavaScriptMsgBack(Response, "檔案類型不符!!", "");
            }
        }

        //'取檔案路徑
        String SavePath = "";
        if (Str_FilePath.IndexOf(":") >= 0)
        {
            SavePath = Str_FilePath;
        }
        else
        {
            SavePath = Server.MapPath(Str_FilePath);
        }
        if (Str_FilePath == "")
        {
            SavePath = Server.MapPath("upload/");
        }


        //'新檔案名稱

        String F_NewFileName = "";
        if (F_FileNameExt != "")
        {
            F_NewFileName = CDEA + "." + F_FileNameExt;
        }
        else
        {
            F_NewFileName = CDEA;
        }

        //'名稱欄位
        String FileSubT = txtFleSub.Text;
        if (FileSubT == "")
        {
            FileSubT = F_FileName;
        }


        //'寫入資料庫
        IzDataSource IzDataSource = new IzDataSource();

        if (Str_FilePath == "")
        {

            //'取得檔案資料
            Byte[] BufferT =new Byte[FileUpload1.PostedFile.InputStream.Length];

            FileUpload1.PostedFile.InputStream.Read(BufferT, 0, Convert.ToInt32(FileUpload1.PostedFile.InputStream.Length));

            String SqlStr = "insert into " + TableName + "(tbFleCde,tbGrpCde,tbFleSub,tbFleCon,tbFleNot,tbFleNme,tbFleTpf,tbFleSiz,tbFleExt,tbFleUtp,tbFlePath,tbFleImg,tbFleCdt,tbFleMdt,tbFleCid,tbFleMid,tbFleCip,tbFleMip) values(@tbFleCde,@tbGrpCde,@tbFleSub,@tbFleCon,@tbFleNot,@tbFleNme,@tbFleTpf,@tbFleSiz,@tbFleExt,@tbFleUtp,@tbFlePath,@tbFleImg,@tbFleCdt,@tbFleMdt,@tbFleCid,@tbFleMid,@tbFleCip,@tbFleMip)";
            //'建立
            IzDataSource.SelectString = SqlStr;
            IzDataSource.ParametersClear();
            IzDataSource.ParametersAdd("tbFleCde", CDEA);
            IzDataSource.ParametersAdd("tbGrpCde", GrpCde);
            IzDataSource.ParametersAdd("tbFleSub", FileSubT);
            IzDataSource.ParametersAdd("tbFleCon", "");
            IzDataSource.ParametersAdd("tbFleNot", "");
            IzDataSource.ParametersAdd("tbFleNme", F_FileName);
            IzDataSource.ParametersAdd("tbFleTpf", F_ContentType);
            IzDataSource.ParametersAdd("tbFleSiz", F_ContentLength);
            IzDataSource.ParametersAdd("tbFleExt", F_FileNameExt);
            IzDataSource.ParametersAdd("tbFleUtp", "db");
            IzDataSource.ParametersAdd("tbFlePath", Str_FilePath);
            IzDataSource.ParametersAdd("tbFleImg", BufferT);
            IzDataSource.ParametersAdd("tbFleCdt", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            IzDataSource.ParametersAdd("tbFleMdt", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            if (LoginUsr.UsrCde != "")
            {
                IzDataSource.ParametersAdd("tbFleCid", LoginUsr.UsrCde);
            }
            else
            {
                //'IzDataSource.ParametersAdd("tbFleCid", LoginMbr.MbrCde)
                IzDataSource.ParametersAdd("tbFleCid", "");
            }
            IzDataSource.ParametersAdd("tbFleMid", "");
            IzDataSource.ParametersAdd("tbFleCip", Request.UserHostAddress);
            IzDataSource.ParametersAdd("tbFleMip", Request.UserHostAddress);

            IzDataSource.SelectDataTable();

        }
        else
        { //'存到資料夾


            //'存檔
            //'檢查是否有此資料夾

            if (!System.IO.Directory.Exists(SavePath + GrpCde))
            {
                System.IO.Directory.CreateDirectory(SavePath + GrpCde);
            }
            FileUpload1.PostedFile.SaveAs(SavePath + GrpCde + "\\" + F_NewFileName);

            //'存三張圖
            String F_NewFileNameS = "";
            if (F_FileNameExt.ToLower() == "jpg" || F_FileNameExt.ToLower() == "gif" || F_FileNameExt.ToLower() == "png")
            {
                //'小縮圖
                F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_S" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                ImageAccess.ResizeImg(ref FileUpload1, Swidth, SavePath + GrpCde + "\\" + F_NewFileNameS);
                //'中縮圖
                F_NewFileNameS = F_NewFileName.Substring(0, F_NewFileName.LastIndexOf(".")) + "_M" + F_NewFileName.Substring(F_NewFileName.LastIndexOf("."));
                ImageAccess.ResizeImg(ref FileUpload1, Mwidth, SavePath + GrpCde + "\\" + F_NewFileNameS);
            }



            String SqlStr = "insert into " + TableName + "(tbFleCde,tbGrpCde,tbFleSub,tbFleCon,tbFleNot,tbFleNme,tbFleTpf,tbFleSiz,tbFleExt,tbFleUtp,tbFlePath,tbFleCdt,tbFleMdt,tbFleCid,tbFleMid,tbFleCip,tbFleMip) values(@tbFleCde,@tbGrpCde,@tbFleSub,@tbFleCon,@tbFleNot,@tbFleNme,@tbFleTpf,@tbFleSiz,@tbFleExt,@tbFleUtp,@tbFlePath,@tbFleCdt,@tbFleMdt,@tbFleCid,@tbFleMid,@tbFleCip,@tbFleMip)";
            //'建立
            IzDataSource.SelectString = SqlStr;
            IzDataSource.ParametersClear();

            IzDataSource.ParametersAdd("tbFleCde", CDEA);
            IzDataSource.ParametersAdd("tbGrpCde", GrpCde);
            IzDataSource.ParametersAdd("tbFleSub", FileSubT);
            IzDataSource.ParametersAdd("tbFleCon", "");
            IzDataSource.ParametersAdd("tbFleNot", "");
            IzDataSource.ParametersAdd("tbFleNme", F_FileName);
            IzDataSource.ParametersAdd("tbFleTpf", F_ContentType);
            IzDataSource.ParametersAdd("tbFleSiz", F_ContentLength);
            IzDataSource.ParametersAdd("tbFleExt", F_FileNameExt);
            IzDataSource.ParametersAdd("tbFleUtp", "file");
            IzDataSource.ParametersAdd("tbFlePath", Str_FilePath);

            IzDataSource.ParametersAdd("tbFleCdt", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            IzDataSource.ParametersAdd("tbFleMdt", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
            if (LoginUsr.UsrCde != "")
            {
                IzDataSource.ParametersAdd("tbFleCid", LoginUsr.UsrCde);
            }
            else
            {
                //'IzDataSource.ParametersAdd("tbFleCid", LoginMbr.MbrCde)
                IzDataSource.ParametersAdd("tbFleCid", "");
            }
            IzDataSource.ParametersAdd("tbFleMid", "");
            IzDataSource.ParametersAdd("tbFleCip", Request.UserHostAddress);
            IzDataSource.ParametersAdd("tbFleMip", Request.UserHostAddress);

            IzDataSource.SelectDataTable();

        }

        IzDataSource.Dispose();

        txtFleSub.Text = "";

        ShowData(); //'處理資料顯示及刪除


    }
}