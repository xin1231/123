﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class fle_FleGet : System.Web.UI.Page
{
    IZCls.DataAccess DataAccess = new IZCls.DataAccess();

     String CDE="" ;
     String GRP="" ;

        String W ="";

        String P ="";

    protected void Page_Load(object sender, EventArgs e)
    {
          //'在這裡放置使用者程式碼以初始化網頁
       if(Context.Request.QueryString["CDE"]!=null)  CDE  = DataAccess.ClsSqlChr(Context.Request.QueryString["CDE"].ToString());
       if (Context.Request.QueryString["GRP"]!=null)  GRP  = DataAccess.ClsSqlChr(Context.Request.QueryString["GRP"].ToString());

        if(Context.Request.QueryString["W"]!=null) W =Context.Request.QueryString["W"].ToString();

        if(Context.Request.QueryString["P"]!=null) P =Context.Request.QueryString["P"].ToString();


        IzDataSource IzDataSource = new IzDataSource();
        String StrSql = "";

        if (GRP != ""){
            StrSql = "select * from tbFle where tbGrpCde=@tbGrpCde";
            IzDataSource.SelectString = StrSql;
            IzDataSource.ParametersClear();
            IzDataSource.ParametersAdd("tbGrpCde", GRP);
        }
        else{
            StrSql = "select * from tbFle where tbFleCde=@tbFleCde";
            IzDataSource.SelectString = StrSql;
            IzDataSource.ParametersClear();
            IzDataSource.ParametersAdd("tbFleCde", CDE);
        }
    

        System.Data.DataTable tb = new System.Data.DataTable();
        tb = IzDataSource.SelectDataTable();

        if( tb.Rows.Count > 0){

            if (tb.Rows[0]["tbFleUtp"].ToString() == "file"){ //'從檔案取

                String Out_FileName =  tb.Rows[0]["tbFleNme"].ToString();

                String F_NewFileName = "";
                if( tb.Rows[0]["tbFleExt"].ToString() != ""){
                    switch(tb.Rows[0]["tbFleExt"].ToString().ToLower()){
                        case "jpg":
                        case "gif":
                        case "png":
                            if (P == "S") {
                                F_NewFileName = tb.Rows[0]["tbFleCde"].ToString() + "_S." + tb.Rows[0]["tbFleExt"].ToString();
                            }
                            else if (P == "M") {
                                F_NewFileName = tb.Rows[0]["tbFleCde"].ToString() + "_M." + tb.Rows[0]["tbFleExt"].ToString();
                            }
                            else{
                                F_NewFileName = tb.Rows[0]["tbFleCde"].ToString() + "." + tb.Rows[0]["tbFleExt"].ToString();
                            }
                                break;
                        default:
                            F_NewFileName = tb.Rows[0]["tbFleCde"].ToString() + "." + tb.Rows[0]["tbFleExt"].ToString();
                            break;

                }
                }
                else{
                    F_NewFileName = tb.Rows[0]["tbFleCde"].ToString();
                }

                Context.Response.ClearHeaders();
                Context.Response.ClearContent();
                Context.Response.Clear();
                Context.Response.Expires = 0;
                Context.Response.Buffer = true;
                Context.Response.AddHeader("Accept-Language", "zh-tw");
                Context.Response.AddHeader("content-disposition", "attachment; filename=\"" + System.Web.HttpUtility.UrlEncode(Out_FileName, System.Text.Encoding.UTF8) + "\"");
                //'Response.AddHeader("content-disposition", "attachment;filename=" & Chr(34) & System.Web.HttpUtility.UrlEncode(Out_FileName, System.Text.Encoding.UTF8) & Chr(34));
                Context.Response.ContentType = tb.Rows[0]["tbFleTpf"].ToString();


                if (tb.Rows[0]["tbFlePath"].ToString().IndexOf (":") > -1){ 
                    Context.Response.TransmitFile(tb.Rows[0]["tbFlePath"].ToString() + tb.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName);
                }
                else{
                    Context.Response.TransmitFile(Server.MapPath(tb.Rows[0]["tbFlePath"].ToString()) + tb.Rows[0]["tbGrpCde"].ToString() + "\\" + F_NewFileName);
                }

            }
            else{  //'從資料庫取

                Byte[] BufferT = (Byte[])tb.Rows[0]["tbFleImg"];

                Context.Response.ClearHeaders();
                Context.Response.ClearContent();
                Context.Response.Clear();
                Context.Response.Expires = 0;
                Context.Response.Buffer = true;
                Context.Response.AddHeader("Accept-Language", "zh-tw");
                Context.Response.AddHeader("content-disposition", "attachment;filename=" + "\"" + System.Web.HttpUtility.UrlEncode(tb.Rows[0]["tbFleNme"].ToString(), System.Text.Encoding.Default) + "\"");
                Context.Response.ContentType = tb.Rows[0]["tbFleTpf"].ToString();

                Context.Response.BinaryWrite(BufferT);


            }

            //'點閱加一
            IzDataSource.ExecuteSQLNoneQuery("update tbFle set tbFleClk=tbFleClk+1 where tbFleCde='" + tb.Rows[0]["tbFleCde"].ToString() + "'");

        }

        tb.Dispose();
        IzDataSource.Dispose();

        Context.Response.End();



    }
}